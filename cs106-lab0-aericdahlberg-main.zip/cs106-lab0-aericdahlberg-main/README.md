#CS 106 Lab 0 - Java Introduction

Name:

Number of Late Days Using for this lab:

### List of tasks for Lab0

[Click here to access the lab0 tasks](https://drive.google.com/file/d/1CbALsYF_HKYD6ipwgEEBrh8dpboKRoqZ/view?usp=sharing)

---

### Lab Questionnaire/Feedback

(None of your answers below will affect your grade; this is to help refine lab assignments in the future)

1. Approximately, how many hours did you take to complete this lab? (provide
  your answer as a single integer on the line below)

2. How difficult did you find this lab? (1-5, with 5 being very difficult and 1
  being very easy)

3. Describe the biggest challenge you faced on this lab:

### Pre-Lab1
[Please click here to see the pre-lab1 practice tasks!](https://docs.google.com/document/d/1wy9NjxruuhutCcLP8uogTyTBaUjBXFjkjinmoKKZiiQ/edit?usp=sharing)
