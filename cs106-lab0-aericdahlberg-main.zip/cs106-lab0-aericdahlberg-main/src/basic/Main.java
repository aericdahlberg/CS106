
package basic;

public class Main {

	public static void main(String[] args) {
		/*
		TODO: You should call the functions you create from this function in order
		to test them. You can check that your Eclipse setup is correct by running
		this file - you should see the below printout in the Console window.  After
		that, you may remove it.
		*/
		//System.out.println(double d = 2.627);
		//System.out.println(power(30,2));
	
		
		double d = 2.627;
		int i = (int) d;
		System.out.println("d is"  + d);
		System.out.println("i is" + i);
		multiplyTil2021(7);
		System.out.println(12%7);
		System.out.println(-12%7);
		System.out.println(13%3);
		System.out.println(-13%3);
		System.out.println(likability(iceCreamFlavors.DOT));
		
		System.out.println(GCD(10,6));
		System.out.println(GCD(5,4));
		System.out.println(GCD(3,12));
		System.out.println(GCD(6,6));
		System.out.println(GCD(200,35));
		System.out.println(GCD(201,33));
		System.out.println(prime(3));
		System.out.println(prime(2));
		System.out.println(prime(1));
		System.out.println(prime(200));
		System.out.println(prime(13));
		System.out.println(prime(27));
		System.out.println(prime(64));
		System.out.println(prime(29));
		System.out.println(prime(2));
		System.out.println(prime(1));
		
		System.out.println(round(2.9));
		System.out.println(round(2.4999));
		System.out.println(round(2.2));
		System.out.println(round(0));
		System.out.println(round(1));
		System.out.println(round(1.2));
		System.out.println(round(4));
		System.out.println(round(336.5));
		System.out.println(round(212.29182));
		System.out.println(classYear(Standing.FIRST_YEAR));
		System.out.println(classYear(Standing.SOPHOMORE ));
		System.out.println(classYear(Standing.JUNIOR));
		System.out.println(classYear(Standing.SENIOR));
		System.out.println(classYear(Standing.GRADUATED));
		
		
		
	}				//prelab work!
	public enum iceCreamFlavors{MINT,VANILLA,CHOCOLATE,LEMON,ORANGE,DOT
	}
	public static boolean myOpinions(iceCreamFlavors flavor) {
		iceCreamFlavors myFavorite = iceCreamFlavors.MINT;
		switch (flavor) {
		case MINT:
			return true;
		case VANILLA:
			return false;			
		case CHOCOLATE:
			return false;
		case LEMON:
			return true;
		case ORANGE:
			return true;
		default:
			System.out.println("This is not a recognized ice cream flavor by order of Eric");
			return false;
		}
		
		
	} 			//prelab work!!!
	public static int likability(iceCreamFlavors flavor) {
		System.out.println("out of 10,");
		switch (flavor) {
		case MINT:
			return 10;
		case VANILLA:
			return 3;			
		case CHOCOLATE:
			return 1;
		case LEMON:
			return 8;
		case ORANGE:
			return 7;
		default:
			System.out.println("This is not a recognized ice cream flavor by order of Eric");
			return 0;
		}
	}
	public static int multiplyTil2021(int orig) {
		int num = orig; 		//create a variable to duplicate the original number
		while (num<2021){		//create a while loop that stops once num is greater than 2021
			num= num* orig; 	//formula that multiplies the variable * the original and stores the new value in itself
		}
		return num;
	}
	
	// TODO: You should add the functions you create for the lab here and below.
	public static int power(int x, int exp) {			//in this i need 2 inputs
		int result = 1;			//create an variable to multiply by x later on
		for (int i=0; i < exp; i++) {		//as long as i is less than exp then for loop will continue
			result = result*x;			//redefine result and new data is stored in result
		}
		return result;
	}
	public static int GCD(int a, int b) {
		while (a != 0 && b!=0) {			//make sure that neither a nor b equals zero, because this is attributed to the base case vvv
			if (a>=b) {						//as i redefine a as b, b as remainder, b  might end up being zero, in which case i know there is no remainder
				int remainder = a%b;		// first if statement treats a>b,second changes a to b and b to a
				a=b;
				b=remainder;
				
			}
			else if (b>a) {
				int z=b;
				b=a;
				a=z;												
			}
		}
		return a;							// as a=b as explained above, the number which dividend the original a, will be b, so the a at the end of the function will be the original b, (or the GCD)
		
	}
	
					
	public static boolean prime(int input) {			// to find if a number is prime lets creat a variable that is one less than the number
		if (input < 2) {								// lets divide number by variable(div)and see if the % =0 (not prime), and keep subtracting div by one continuing the process. 
			return false;								// then num%div will either equal 0(not prime) or div will reach 1(prime)
		}
		else if (input == 2) {							// base cases in input is < 2 bc then it is not a prime or if it equals 2 it is a prime
			return true; 
		}
		else { 
			int div = input -1;
			while (div != 1) {
				if (input%div == 0) {					// while loop lets us use div and subtract it by one each iteration till cases are filled
					
					return false;
				}
				else {
					div = div-1;
				
					
				}
				
				
			}
			return true;
		}
		
	}
	
	public static int round(double prospect) {				//in this method i set a double variable, helper, as the remainder of prospect
		double helper = prospect%1;							// this means I can now see if it >.5 or not and round it, or not
		if (helper < .5) {
			return (int) prospect;							// though i can only do this if i redefine double as int, (int) prospect
		}
		else {
			return ((int)prospect + 1);
		}
						
		
	}

	
	public enum Standing {FIRST_YEAR, SOPHOMORE, JUNIOR, SENIOR, GRADUATED};
	
	public static String classYear(Standing year) {
		if (year.equals(Standing.FIRST_YEAR)) {								// after creating my enum i make some if statements
			return "Class of 2024";
		}
		else if (year.equals(Standing.SOPHOMORE)) {				//this just takes special syntax to figure out how to call on the enums
			return "Class of 2023";
		}														// USE year.equals for enums
		else if (year.equals(Standing.JUNIOR)) {	
			return "Class of 2022";						// use Standing{the enum Name}.{name in list}
		}	
		else if (year.equals(Standing.SENIOR)) {
			return "Class of 2021";								//String can be returned by ""
		}
		else return "Not currently in College";
	}
						
	
}

//Approximately, how many hours did you take to complete this lab? (provide your answer as a single integer on the line below)
// 5.5
//How difficult did you find this lab? (1-5, with 5 being very difficult and 1 being very easy)
//4.5- i had never used java before and syntax was hard
//Describe the biggest challenge you faced on this lab:
//the biginning, figuring out how the syntax worked and reaclimating my brain to do coding