## CS 106 Lab 2: Data Structure Design

Name: Eric Bianca
Number of Nonpenalty Late Day(s) Used for Lab: 1 (so submitted by Thursday, 3/11 rather than Tuesday, 3/9)

---

### 3.2 Questions
1. If any of your validation methods indicate that your precondition assumptions were not met by the data, document what preconditions were violated and in what way. Update your validation methods one error at a time, documenting all issues, until you can read in all the data. If this did not happen mention that.
All of our precondition assumptions were met by the data. They were, 
- Sex is "male" or "female"
- Race must be African American, Caucasian, Hispanic, or Other
- criminalChargeDegree must be F or M
- criminalChargeDesc should be a string describing their offense
- decileScore should be an integer from 1 to 10
- score_text should be Low, Medium, or High
- recidChargeDesc should be a string if defendant committed another crime within 2 years of the first one (empty string if they did not)
- recidChargeDegree should be a String, F1, F2, F3, M1, M2, or M3 (Felony or Misdemeanor first, second, or third degree)

2. Describe a person who would generate data that would not pass your (updated) precondition assumptions.
The holes in our preconditions are as follows:
There could be some user error. For instance, if someone inputs race incorrectly, such as "african American" instead of "African American". Because the enum is case sensitive, the output would be "Other" so another assumption is that the input has to be correct. Similarly, if someone inputs score_text incorrectly, such as "low" instead of "Low", the output would also be "Other." Because the enum is case sensitive, the output would be "Other" so another assumption is that the input has to be correct. Also, we expect the two_year_recid column to contain a "0" or a "1", which we then interpret in the method hasReoffended() to mean false or true, respectively. If the user has a csv file that says yes or no or true or false, then our CompasProfile constructor that takes in a String array is not going to store the correct boolean value for recidivism.
  
---

### Analysis for Question 5
We wrote two new methods. The first one, mitigateRecidCharge() in the CompasProfile class. The second was organizerNewCharge(), was in SampleCompasProfiles (this runs exactly like organizer but with the additional line of calling mitigateRecidCharge() before the if statements. We chose to take charges such as suspension of driver's license, petit theft, resisting or obstructing without violence, entering a city park after hours, forging a document, and possessing or selling cannabis, as ones that did not qualify for recidivism.
When running the new method, our table showed increasing false positivity rates for both races, and slightly decreasing false negativity rates for white people, and slightly increasing false negativity rates for Black people. For white people, false positive rates increased from 23.5% to 26.3%, and false negative rates decreased from 47.42% to 47.1%. For Black people, false positive rates increased from 44.85% to 50.6%, and false negative rates increased slightly from 28.0% to 28.5%. The disparities between false positive and false negative rates remained pretty wide between white and Black people. That is, the COMPAS still shows severe racial bias, even when we reduce slightly the scope of charges that send people to jail. 

### Read about pair programming and how to navigate through it

I recommend you to read the pair ["Pair Programming Guide - Please read this before you start working on the assignment.pdf"](https://drive.google.com/file/d/1tmSYwfKKXeMVDXvT6q5fPHPbF_vMF9Z4/view?usp=sharing). Make sure you fill the log provided in **pair-programming folder** as accurately as possible. The log shall be graded. 

### Work on pre-lab

Pre-labs are to prepare you for the actual lab. Please take a look at pre-lab2-tasks.pdf in cs106-lab2/tasks/ to read the pre-lab2 tasks. 

### Work on the lab tasks
Tasks that you have to complete are listed in lab2_tasks.pdf provided in cs106-lab2/tasks/. Please spend time reading the tasks and planning how you would complete them with your partner before implementing them.  

### Reuse of what you have already completed
The tasks of this lab, build upon the tasks that you have completed in lab1. Please make reuse of the code that you have already written in lab1. 


### Lab resources are also available in the Google Drive folder shared with you, which has lectures and slides. 

[Google Drive Links for lecture, lab, and assignment](https://drive.google.com/drive/folders/1EuAYlyaFLN97TI7PzW0b8PfPxxaD5Zsk?usp=sharing)

### Additional Lab Questionnaire

(None of your answers below will affect your grade; this is to help refine lab
assignments in the future)

1. Approximately how many hours did you take to complete this lab? (provide your answer as a single integer on the line below)
16


2. How difficult did you find this lab? (1-5, with 5 being very difficult and 1 being very easy)

5

3. Describe the biggest challenge you faced in this lab:

Syntax and using the constructors correctly/organizing instance variables. Questions 2 and 3. Debugging boolean methods. Organizing testing and methods in the Main class.





