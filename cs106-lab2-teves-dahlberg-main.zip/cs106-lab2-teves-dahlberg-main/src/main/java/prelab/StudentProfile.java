package prelab;
import java.util.ArrayList;
	/*
	1. Each row of the file StudentProfile.csv represents an object,
	an instance of a class that could be called StudentProfile.

	2. List all the variables stored in the csv profile: 
	Name, Age, Class Year, Dorm, Have an on campus job?, Dean

	3. Next to each variable, list the most appropriate type:
	Name - String
	Age - int
	Class Year - int
	Dorm - String
	Have an on campus job? - Boolean
	Dean - String
	*/

import org.junit.Assert;

//import propublica.datadesign.CompasProfile;


public class StudentProfile {
		// Instance variables
		// Creating a new object that is an array of strings
	private String studentName;
	private int age;
	private ClassYear classYear;
	private Dorm dorm;
	private Dean dean;
	public enum ClassYear {FIRST_YEAR, SOPHOMORE, JUNIOR, SENIOR, GRADUATED};
	//public classYear standing;
	public enum Dorm {BARCLAY, TRITTON, JONES, GUMMERE, APARTMENTS, KIM, LEEDS,
	LLOYD, QHOUSE, DRINKER, BCC, COMFORT, LUNT};

	public enum Dean {MICHAEL_ELIAS, KATRINA_GLANZER, MARTHA_DENNEY, THERESA_TENSUAN,
	BRIAN_CUZZOLINA, KELLY_WILCOX};
		
	// Getters
	public String getStudentName() { return studentName; }
	public int getAge() { return age; }
	public String strClassYear()
	{
		switch (classYear)
		{
		case FIRST_YEAR:
			return "Low";
		case SOPHOMORE:
			return "Sophomore";
		case JUNIOR:
			return "Junior";
		case SENIOR:
			return "Senior";
		default:
			System.out.println("Not a valid class year");
			return "";
		}
	}
	// Constructors											
	public StudentProfile(String studentName, int age, ClassYear classYear, Dorm dorm, Dean dean)
	{
	this.studentName = studentName;
	this.age = age;
	this.classYear = classYear;
	this.dean = dean;
	this.dorm= dorm;
	}
	
	/**
	 * 	NEW CONSTRUCTOR - takes all inputs from first constructor, converts to string, then puts into stirng array
	 * @param studentName
	 * @param age
	 */
	public StudentProfile(String[] array) 
	{
		this.studentName = array[0];
		this.age = Integer.parseInt(array[1]);
		//this.classYear = array[2];			// WHY ISNT THIS WORKING?
		this.classYear = ClassYear.JUNIOR;
		this.dean = Dean.BRIAN_CUZZOLINA;
		this.dorm = Dorm.APARTMENTS;

	}
	// Constructor that initializes the instance variable into the new ArrayList
	public StudentProfile(String studentName, String age)
	{
	this.studentName = studentName;
	this.age = Integer.parseInt(age);
	}
		
	// Overriding toString method
	@Override
	public String toString() 
	{
		return "Name: " + getStudentName() + "		" +
		" Age: " + Integer.toString(getAge())+ "\n";
	}
}
