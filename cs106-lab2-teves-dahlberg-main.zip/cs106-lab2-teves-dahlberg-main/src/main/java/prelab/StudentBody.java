package prelab;

import java.util.ArrayList;

public class StudentBody {
	
	// variable that holds the rows of StudentInformtion
	private ArrayList<StudentProfile> datad;
	
	// constructor
	public StudentBody()
	{
		//What instance variable are we initializing into a newArrayList
		datad = new ArrayList<StudentProfile>();
		
	}
	
	// Prelab 2 Step 4 (option a)
	public void studentBodyFiller(ArrayList<String[]> studentRows)
	{
		for(String[] row : studentRows)
		{
			StudentProfile studentRow = new StudentProfile(row);
			datad.add(studentRow);
		}
			
	}
	// 
	public ArrayList<StudentProfile> getDatad() 
	{
		return datad;
	}
	@Override
	public String toString()
	{
		StringBuilder str = new StringBuilder();
		for(StudentProfile student : getDatad())
		{
			str.append(student.toString() + "\n");
		}
		return str.toString();
	}
	
	
	
}
