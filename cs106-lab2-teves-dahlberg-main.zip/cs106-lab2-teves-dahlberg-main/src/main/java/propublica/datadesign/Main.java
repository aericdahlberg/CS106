package propublica.datadesign;
//The tasks of this lab, build upon the tasks that you have completed in lab1. 
//Please make reuse of the code that you have already written in lab1.

import java.io.FileNotFoundException;
import org.junit.Assert;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;

import com.opencsv.CSVReaderHeaderAware;
//import org.junit.Assert;
//import prelab.StudentBody;
//import propublica.datadesign.CompasProfile.Race;
//import propublica.datadesign.CompasProfile.ScoreText;
//
//import propublica.datadesign.CompasProfile.Race;
//import propublica.datadesign.CompasProfile.ScoreText;

/**
 * Hello world!
 *
 */
public class Main {
	// this should become the "Prediction Fails Differently for Black Defendants" table
	public static PropublicaDataTable racialBiasTable = null;
	
    public static void main( String[] args ) 
    {
        // TODO: eventually set racialBiasTable to a new PropublicaDataTable with correct values.
//    	String bigTest = testAdding();
//    	System.out.println(bigTest.toString());
    
    	
//    	System.out.println(testAdding());
    	
//    	CompasProfile person1 = new CompasProfile ("Male", Race.OTHER, 
//				"F", "Aggravated Assault w/Firearm", 1, ScoreText.LOW, false, "","");
//    	System.out.println(person1.toString());
    	
//    	for (String[] str: testAdding()){
//    		System.out.println(Arrays.toString(str));
    	
    	/**
    	 * JUnit Testing for hasReoffended() on object type CompasProfile
    	 * Code suggested by Steve on Piazza
    	 */
    	//testConstructor();
    	
    	
    	
    	CSVReaderHeaderAware reader;
		try 
		{
			// Code copied from lab tasks to read in the csv data
			reader = new CSVReaderHeaderAware(new FileReader("compas-scores.csv"));
			ArrayList<String[]> myEntries = new ArrayList<String[]>(reader.readAll());
			reader.close();
			
			// Populating new SampleCompasProfiles object with myEntries
			SampleCompasProfiles fullDataset = new SampleCompasProfiles();
			fullDataset.compasProfileFiller(myEntries);
			System.out.println(fullDataset.toString());
			 
			//4.2 TEST!!!!!
			String product = fullDataset.organizer();
			System.out.println(product);
			
			//5.1 additional optional analysis
			//String productEdited=fullDataset.organizerNewCharge();
			//System.out.println(productEdited);
			
			System.out.println(fullDataset.whiteFalsePositive());
			System.out.println(fullDataset.whiteFalseNegative());
			System.out.println(fullDataset.blackFalsePositive());
			System.out.println(fullDataset.blackFalseNegative());
//			double wfn = fullDataset.whiteFalseNegative();
//			double bfp = fullDataset.blackFalsePositive();
//			double bfn = fullDataset.blackFalseNegative();
//			System.out.println("White FP: " + wfp + "\n White FN: " + wfn);
//			System.out.println("Black FP: " + bfp + "\n Black FN: " + bfn);
			double HighNoReoffendWhite = fullDataset.whiteFalsePositive();
			double HighNoReoffendBlack = fullDataset.blackFalsePositive();
			double LowRecidivateWhite = fullDataset.whiteFalseNegative();
			double LowRecidivateBlack = fullDataset.blackFalseNegative();
			
			
			
			//PropublicaDataTable myTable = new PropublicaDataTable(HighNoReoffendWhite, HighNoReoffendBlack, LowRecidivateWhite, LowRecidivateBlack);
			//racialBiasTable = myTable;
			racialBiasTable = new PropublicaDataTable(HighNoReoffendWhite, HighNoReoffendBlack, LowRecidivateWhite, LowRecidivateBlack);

			System.out.println(racialBiasTable.toString()); 
			
//			System.out.println(fullDataset.whiteFalsePositive());
//			System.out.println(fullDataset.blackFalsePositive());
			
		} 
		catch (IOException e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }
    
    
    
    /**
	 * JUnit Testing for hasReoffended() on object type CompasProfile
	 * Code suggested by Steve on Piazza
	 */
    private static void testConstructor() 
    {
		// TODO Auto-generated method stub
	
    	//Tests for hasReoffended method
		String[] row1 =  new String[] {"Male", "Other", "F", "Aggravated Assault w/Firearm", "1", "Low", "0", "", ""};
		String[] row2 =  new String[] {"Female", "Caucasian", "M", "Battery", "6", "Medium", "1", "(F1)", "Hello world"};
		CompasProfile person1 = new CompasProfile(row1);
		CompasProfile person2 = new CompasProfile(row2);
		Assert.assertEquals(true, person1.hasReoffended()); 
		Assert.assertEquals(true, person2.hasReoffended());  
	}
    

//    	System.out.println(testAdding());
    	
//    	SampleCompasProfiles compasSample = new SampleCompasProfiles();		
//    	compasSample.studentBodyFiller(dataReadRows);
//    	System.out.println(compasSample.toString());
    
    
/**
 * testAdding() method (Lab 2 2.3.3)
 * Figure Out Later
 * @return
 */
    public static String testAdding()
    {
    	
    	// Manually input data from csv file
    	String[] row1 = {"Male", "Other", "F", "Aggravated Assault w/Firearm", "1", "Low", "0", "", ""};
    	String[] row2 = {"Male", "African-American", "F", "Felony Battery w/Prior Convict", "3", "Low", 
    				"1", "Felony Battery (Dom Strang)", "F3"};
    	String[] row3 = {"Male", "African-American", "F", "Possession of Cocaine", "3", "Low", "1", 
    			"Driving Under The Influence", "M1"};
    	
    	ArrayList<String[]> smallSample = new ArrayList<String[]>();
    	smallSample.add(row1);
    	smallSample.add(row2);
    	smallSample.add(row3);
    	
    	//Arrays.asList(row1);
    	//smallSample.add(Arrays.asList(row2));
    	
    	// Creating test SampleCompasProfiles
		SampleCompasProfiles test = new SampleCompasProfiles();
		test.compasProfileFiller(smallSample);
		return test.organizer();
		
		//creating white and black false positives and false negatives
		
    }
}
