/**
 * 
 * Lab 2
 * Class for representing all of the rows in the dataset
 * An object is of the entire csv file so we can replicate Propublica's analysis.
 * @author: Bianca Teves, Eric Dahlberg
 * @version: Tuesday, March 9th, 2021
 * 
 */

package propublica.datadesign;
//import propublica.datadesign.CompasProfile;
import java.util.ArrayList;
public class SampleCompasProfiles {
	
	// instance variable - holds an ArrayList for all of profiles in the csv file
	public ArrayList<CompasProfile> datad;
	public int numberRows = 0;
	
	/**
	 * Default constructor method
	 * Initializes the instance variable as an empty ArrayList
	 * which we will populate with our csv data
	 */
	public SampleCompasProfiles()
	{
		datad = new ArrayList<CompasProfile>();
	}
	
	/**
	 * LAB 2 (2.3.2)
	 * Method to populate our empty dataset with the csv data
	 * @param compasRows: the ArrayList of String arrays read in
	 * 			from the csv file
	 * For each row of csv data, we convert the String array into
	 * a CompasProfile object, and add this new object into
	 * the instance variable (the ArrayList of Compas Profiles).
	 */
	public void compasProfileFiller(ArrayList<String[]> compasRows)
	{
		for(String[] i : compasRows)
		{
			// calls constructor that takes in String array to make CompasProfile object
			CompasProfile compasRow = new CompasProfile(i);
			datad.add(compasRow);
		}
	}
	/*
	 * Getter for instance variable data
	 */
	public ArrayList<CompasProfile> getDatad() 
	{
		return datad;
	}
	/*
	 * 
	 */
	@Override
	public String toString()
	{
		StringBuilder str = new StringBuilder();
		for(CompasProfile j : getDatad())
		{
			str.append(j.toString() + "\n");
		}
		return str.toString();
	}
	
	
	
	/**
	 * Instance variables we are declaring for Question 4
	 * Eight variables represent, by race, the number of people who reoffended....
	 */
	//most important 
	//w=white b=black   no=did not reoffend     Yes= did reoffend  
	//Low= labeled low risk              High = labeled high risk
	private int bNoHigh = 0;
	private int wNoHigh = 0;
	private int bYesLow = 0;
	private int wYesLow = 0;
	//other not needed
	private int bNoLow = 0;
	private int wNoLow = 0;
	private int bYesHigh = 0;
	private int wYesHigh = 0;
	double wFP; 
	double wFN;
	double bFP;
	double bFN;

	/**
	 * Organizer method
	 * Functions like a giant setter for each of the 8
	 * fields declared above
	 */
	
	/**
	 * 
	 * @return
	 */
	public String organizer() 
	{
		for (CompasProfile row : datad) 
		{ 
			//CompasProfile person = datad.get(i);
			if (row.isWhite()) 
			{
				if (row.hasReoffended()==true)
				{
					if (row.isHighRisk()==true) 
					{
					wYesHigh++;
					}
					else
					{
					wYesLow++;
					}
				}
				else if (row.hasReoffended()==false)
				{
					if (row.isHighRisk()==true) 
					{
					wNoHigh++;
					}
					else
					{
					wNoLow++;
					}
				}
			}
			else if (row.isBlack())
			{
				if (row.hasReoffended()==true)
				{
					if (row.isHighRisk()==true) 
					{
					bYesHigh++;
					}
					else // person has not reoffended
					{
					bYesLow++;
					}
				}
				else if (row.hasReoffended()==false)
				{
					if (row.isHighRisk()==true) 
					{
						bNoHigh++;
					}
					else
					{
						bNoLow++;
					}
				}
			}
		
			
		}
		return "wNoLow: " + wNoLow + "	wNoHigh: " + wNoHigh + "\n" +
		"wYesLow: " + wYesLow + "	wYesHigh: " + wYesHigh + "\n" +
		"bNoLow: " + bNoLow + "	bNoHigh: " + bNoHigh + "\n " +
		"bYesLow: " + bYesLow + "	bYesHigh: " + bYesHigh + "\n";
	}
		
		
		//*
		//5.1 This is our optionally run method that 
		//takes some boolean recid values and changes them
		//*
		public String organizerNewCharge() 
		{
			for (CompasProfile row : datad) 
			{ 
											
				row.mitigateRecidCharge(); //only difference between organizer and OrganizerNewCharge
											
				//CompasProfile person = datad.get(i);
				if (row.isWhite()) 
				{
					if (row.hasReoffended()==true)
					{
						if (row.isHighRisk()==true) 
						{
						wYesHigh++;
						}
						else
						{
						wYesLow++;
						}
					}
					else if (row.hasReoffended()==false)
					{
						if (row.isHighRisk()==true) 
						{
						wNoHigh++;
						}
						else
						{
						wNoLow++;
						}
					}
				}
				else if (row.isBlack())
				{
					if (row.hasReoffended()==true)
					{
						if (row.isHighRisk()==true) 
						{
						bYesHigh++;
						}
						else // person has not reoffended
						{
						bYesLow++;
						}
					}
					else if (row.hasReoffended()==false)
					{
						if (row.isHighRisk()==true) 
						{
							bNoHigh++;
						}
						else
						{
							bNoLow++;
						}
					}
				}
			
				
			}
//		wFP = whiteFalsePositive();
//		wFN = whiteFalseNegative();
//		bFP = blackFalsePositive();
//		bFN = blackFalseNegative();
//		whiteFalsePositive();
//		whiteFalseNegative();
//		blackFalsePositive();
//		blackFalseNegative();
		return "wNoLow: " + wNoLow + "	wNoHigh: " + wNoHigh + "\n" +
			"wYesLow: " + wYesLow + "	wYesHigh: " + wYesHigh + "\n" +
			"bNoLow: " + bNoLow + "	bNoHigh: " + bNoHigh + "\n " +
			"bYesLow: " + bYesLow + "	bYesHigh: " + bYesHigh + "\n";
//			+ "\n" + "white False Positive" + wFP + "\n" + "white False Negative" 
//			+ wFN + "\n" + "black False Positive" + bFP + "\n" + 
//			"black False Negative" + bFN;
		
	}
	
	public double whiteFalsePositive()
	{
//		System.out.println(this.wNoHigh);
//		System.out.println(this.wNoLow);
		wFP = (double)((double) this.wNoHigh/((double) this.wNoHigh + (double) this.wNoLow));
//		System.out.println(this.wNoHigh/(this.wNoHigh + this.wNoLow));
		return wFP;
	}
	public double whiteFalseNegative()
	{
		wFN = (double)((double) this.wYesLow/((double) this.wYesLow + (double) this.wYesHigh));
		return wFN;
	}
	public double blackFalsePositive()
	{
		bFP = (double)((double) this.bNoHigh/((double) this.bNoHigh + (double) this.bNoLow));
		return bFP;
	}
	public double blackFalseNegative()
	{
		bFN = (double)((double) this.bYesLow/((double) this.bYesLow + (double) this.bYesHigh));
		return bFN;
	}
//	public static void Main(String[] args) {
//	System.out.println("wNoLow: " + wNoLow + "	wNoHigh: " + wNoHigh);
//	}
}
