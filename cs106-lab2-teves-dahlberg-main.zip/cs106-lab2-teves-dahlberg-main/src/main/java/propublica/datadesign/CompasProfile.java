/**
 * Compas Profile class copied and pasted from Lab 1
 * Reflects necessary edits and changes for Lab 2
 * The CompasProfile class holds data for people who were arrested
 * and evaluated via the COMPAS assessment, or 
 * correctional Offender Management Profiling for Alternative Sanctions.
 * it includes their name, race, charge degree and description,
 * COMPAS score,whether they committed another crime 2 years
 * after their arrest, and if applicable their second charge
 * degree and description.
 * 
 * @author: Bianca Teves and Eric Dahlberg
 * @version: Tuesday, March 2nd, 2021
 */

package propublica.datadesign;

public class CompasProfile
{
	/*
	 * Instance variables:
	 * Attributes to inmates, declared in the order
	 * in which they appear in the .csv file.
	 * Preconditions: 
	 * 		Sex is "male" or "female"
	 * 		Race must be African American, Caucasian, Hispanic, or Other
	 * 		criminalChargeDegree must be F or M
	 * 		criminalChargeDesc should be a string describing their offense
	 * 		decileScore should be an integer from 1 to 10
	 * 		score_text should be Low, Medium, or High
	 * 		recidChargeDesc should be a string if defendant committed another crime 
	 * 			within 2 years of the first one (empty string if they did not)
	 * 		recidChargeDegree should be F1, F2, F3, M1, M2, or M3 (Felony or Misdemeanor
	 * 			first, second, or third degree
	 */
	private String sex;
	private Race race; 
	private String criminalChargeDegree;
	private String criminalChargeDesc;
	private int decileScore;
	private ScoreText score_text;
	private boolean twoYearRecid;
	private String recidChargeDesc;
	private String recidChargeDegree;
	
	
	// enums for the instance variables
	public enum Race {AFRICAN_AMERICAN, CAUCASIAN, HISPANIC, OTHER};
	public enum ScoreText {LOW, MEDIUM, HIGH};
	
	
	/**
	 * Method raceString
	 * Turns string for race back into enum
	 * for the purposes of the second constructor
	 */
	public Race raceString(String race) 
	{
		switch (race) 
		{
		case "African-American":
			return Race.AFRICAN_AMERICAN;	
		case "Caucasian":
			return Race.CAUCASIAN;
		case "Hispanic":
			return Race.HISPANIC;
		default:
			return Race.OTHER;
		}
	}
	
	/**
	 * Getter for sex @TODO: OR DO WE NEED GETTERS FOR FIELDS OF TYPE STRING?
	 * Added for Lab 2
	 */
	public String getSex()
	{
		return sex;
	}
	
	/**
	 * Getter for race
	 * Takes the enum value and returns appropriate string
	 */
	public String getRace() 
	{  
		switch (race) 
		{
		case AFRICAN_AMERICAN:
			return "African-American";	
		case CAUCASIAN:
			return "Caucasian";
		case HISPANIC:
			return "Hispanic";
		case OTHER:
			return "Other";
		default:
			System.out.println("This Race is not in the database");
			return "";
		}
	}	
	
	/**
	 * Getter for criminal Charge Degree
	 * @param criminalChargeDegree
	 */
	public String criminalChargeDegree() 
	{ return criminalChargeDegree; }
	
	/**
	 * Getter for decileScore
	 * @param getDecileScore
	 */
	public int getDecileScore() 
	{ 
		return decileScore;
	}
	
	/**
	 * Setter for decileScore
	 * Allows us to change the person's COMPAS score
	 * @param newScore
	 */
	public void setdecileScore(int newScore)
	{
		this.decileScore = newScore;
	}
	
	/**
	 * Method scoreTextString
	 * Turns string for ScoreText back into enum
	 * for the purposes of the second constructor
	 */
	public ScoreText scoreTextString(String scoreText) 
	{
		switch (scoreText) 
		{
		case "Low":
			return ScoreText.LOW;	
		case "Medium":
			return ScoreText.MEDIUM;
		default:
			return ScoreText.HIGH;
		}
	}
	/**
	 * Getter for getScoreText
	 * @return void
	 */
	public String getScoreText()
	{
		switch (score_text)
		{
		case LOW:
			return "Low";
		case MEDIUM:
			return "Medium";
		case HIGH:
			return "High";
		default:
			System.out.println("Not a valid score text");
			return "";
		}
	}
	
	/**
	 * Constructor the the profile of the defendant.
	 * Uses every instance variable above, following
	 * the format of the compas-scores.csv file.
	 * @param sex
	 * @param race
	 * @param criminalChargeDegree
	 * @param criminalChargeDesc
	 * @param decileScore
	 * @param score_text
	 * @param twoYearRecid
	 * @param recidChargeDesc
	 * @param recidChargeDegree
	 */
	public CompasProfile(String sex, Race race, String criminalChargeDegree,
			String criminalChargeDesc, int decileScore, ScoreText score_text,
			boolean twoYearRecid, String recidChargeDesc,
			String recidChargeDegree)
	{
		this.sex = sex;
		this.race = race;
		this.criminalChargeDegree = criminalChargeDegree;
		this.criminalChargeDesc = criminalChargeDesc;
		this.decileScore = decileScore;
		this.score_text = score_text;
		this.twoYearRecid = twoYearRecid;
		this.recidChargeDesc = recidChargeDesc;
		this.recidChargeDegree = recidChargeDegree;
	}
	
	/**
	 * New Constructor for Lab 1 Section 2.1
	 * Uses every instance variable above, following
	 * the format of the compas-scores.csv file.
	 * @param fields
	 */
	public CompasProfile(String[] array) 
	{
		
		this.sex = array[0];
		this.race = raceString(array[1]);
		this.criminalChargeDegree = array[2];
		this.criminalChargeDesc = array[3];
		this.decileScore = Integer.parseInt(array[4]);
		this.score_text = scoreTextString(array[5]);
		String hasReoffended = array[6];
		if (hasReoffended.contains("1"))
		{
			this.twoYearRecid = true;
		}
		else
		{
			if (hasReoffended.contains("0"))
			{
				this.twoYearRecid = false;
			}
		}
		this.recidChargeDesc = array[7];
		this.recidChargeDegree = array[8];
	}
	
	/**
	 * toString() method for CompasProfile
	 * (Optional portion from Lab 1 that we are doing now for Lab 2)
	 */
	@Override
	public String toString()
	{
		return "Sex: " + this.sex +	"	" + "Race: " + this.getRace() + "	" + "C_Charge_Degree: " + this.criminalChargeDegree +
				"	" + "C_Charge_Desc: " + this.criminalChargeDesc + "				" + "Decile_Score " + this.getDecileScore() +
				"	" + "Score_Text: " + this.getScoreText() + "		" + "2_Yr_Recid: " + this.twoYearRecid
				+ "		" + "R_Charge_Desc " + this.recidChargeDesc + "				" + "R_Charge_Deg: " + 
				this.recidChargeDegree;
	}
	
	/**
	 * Boolean Methods
	 * These 5 methods will be used to determine what percentage defendants fall into 
	 * in Propublica's Chart, "Prediction Fails Differently for Black Defendants"
	 */
	
	/**
	 * isWhite method
	 * Checks if defendant is white
	 * @return
	 */
	public Boolean isWhite()
	{
		if (this.getRace() == "Caucasian") 
			return true;
		else
			return false;
	}
	
	/**
	 * isBlack method
	 * Checks if defendant is Black
	 * @return
	 */
	public Boolean isBlack()
	{
		if (this.getRace() == "African-American") 
			return true;
		else
			return false;	
	}
	
	/**
	 * hasReoffended method
	 * Checks if defendant has reoffended within 2 years after their initial crime
	 */
	public Boolean hasReoffended()
	{
		if (this.twoYearRecid == true)
			return true;
		else
			return false;
	}
	
	/**
	 * isLowRisk method
	 * Checks if defendant was evaluated by COMPAS to have a lower possibility of
	 * committing another crime
	 */
	public Boolean isLowRisk()
	{
		if (this.getScoreText() == "Low")
			return true;
		else
			return false;
	}
	
	/**
	 * is HighRisk method
	 * Checks if defendant was evaluated by COMPAS to have a higher possibility of
	 * committing another crime. Note that High and Medium both return true
	 * @return
	 */
	public Boolean isHighRisk()
	{
		if (this.getScoreText() == "High" || this.getScoreText() == "Medium")
			return true;
		else
			return false;
	}
	
	/**
	 *
	 * new method looking at mitigating some of the charges against the inmates so to
	 * return false instead of true for twoYearRecid. a-g are the recidCharges we 
	 * decided to make obsolete. 
	 * @return
	 */
	public void mitigateRecidCharge()
	{
		boolean a = this.recidChargeDesc.contains("Driving License Suspended");
				
		boolean b = this.recidChargeDesc.contains("Petit Theft");
					
		boolean c= this.recidChargeDesc.contains("Resist/Obstruct W/O Violence");
						
		boolean d= this.recidChargeDesc.contains("Enter City Park/ Prohibited Hrs");
			
		boolean e= this.recidChargeDesc.contains("Uttering a Forged Instrument");
		
		boolean f= this.recidChargeDesc.contains("cannabis");
		
		boolean g= this.recidChargeDesc.contains("drive");
		
		if (this.twoYearRecid == true)
		{
			
			
			if (a||b||c||d||e||f||g)
			{
				this.twoYearRecid = false;
			}
			
			
			
				
		
				
		}
			
	}
	
	
}
	
