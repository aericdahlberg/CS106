package propublica.datadesign;

import org.junit.Assert;

import propublica.datadesign.CompasProfile.Race;
import propublica.datadesign.CompasProfile.ScoreText;

/**
 * Main Class is for testing our constructor and Boolean methods.
 * @author Bianca Teves and Eric Dahlberg
 * Tuesday, March 2nd, 2021
 */
public class Main {
	
    public static void main( String[] args ) {
    	testObject();
    	testBools();
    	testStringArrConstructor();
        // TODO: eventually set racialBiasTable to a new PropublicaDataTable with correct values.	
    }
    
    
			//why static method?
	public static void testObject() 
	{
		CompasProfile person1 = new CompasProfile ("Male", Race.OTHER, 
				"F", "Aggravated Assault w/Firearm", 1, ScoreText.LOW, false, "","");
				
				System.out.println(person1.getRace());
				Assert.assertEquals("Other", person1.getRace());
				person1.setdecileScore(2);
				Assert.assertTrue(person1.getDecileScore() == 1);
				Assert.assertFalse(person1.getDecileScore() == 1);
				Assert.assertEquals("Other", person1.getRace());
				//Assert.assertEquals(Race.OTHER, person1.getRace());

		
	}
	// this should become the "Prediction Fails Differently for Black Defendants" table
	public static void testBools() 
	{
		CompasProfile person2 = new CompasProfile ("Male", Race.OTHER, 
				"F", "Aggravated Assault w/Firearm", 1, ScoreText.LOW, false, "","");
		// None of these should raise an exception
		Assert.assertTrue(person2.isWhite() == false);	
		Assert.assertFalse(person2.isBlack());			
		Assert.assertFalse(person2.hasReoffended());
		Assert.assertTrue(person2.isLowRisk());
		Assert.assertFalse(person2.isHighRisk());
	}
	public static PropublicaDataTable racialBiasTable = null;
	
	public static void testStringArrConstructor() 
	{
		String[] row1 = new String[] {"Male", "Other", "F",
		"Aggravated Assault w/Firearm", "1", "Low", "0", "", ""};
		CompasProfile person3 = new CompasProfile(row1);
		Assert.assertEquals("Other", person3.getRace());
	}
	
	
}
