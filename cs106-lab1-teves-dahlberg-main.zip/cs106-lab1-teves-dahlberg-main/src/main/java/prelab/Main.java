package prelab;

import prelab.StudentInformation.ClassYear;
import prelab.StudentInformation.Dean;
import prelab.StudentInformation.Dorm;
import org.junit.Assert;

/*
 * You should use this package for Pre-Lab 2 and Pre-Lab 3 Exercises.
 * Make sure you don't have errors in this package, since it will cause issues
 * with the autograder if there are any compilation issues.
 */

/*
Before Coding
1. Each row of the file StudentProfile.csv represents an object,
an instance of a class that could be called StudentProfile.

2. List all the variables stored in the csv profile: 
Name, Age, Class Year, Dorm, Have an on campus job?, Dean

3. Next to each variable, list the most appropriate type:
Name - String
Age - int
Class Year - int
Dorm - String
Have an on campus job? - Boolean
Dean - String


 
 */







public class Main
{
	
	
		
	
	
	public static void testConstructors() 
	{
		StudentInformation student1 = new StudentInformation("Will", 20, 
			ClassYear.SOPHOMORE, Dorm.BARCLAY, Dean.MICHAEL_ELIAS);
		
		StudentInformation student2 = new StudentInformation("Will", "20" 
				);
			System.out.println(student1.getAge());
			Assert.assertEquals(student1.getStudentName(), "Will");
			Assert.assertFalse(student1.getStudentName().equals("Wall"));
			Assert.assertTrue(student1.getStudentName().equals("Wall"));
			System.out.println(student1.getAge());
	}

	
	
	
	
	
	
	public static void main(String[] args) 
	{
		// TODO complete your pre-labs!
		testConstructors();
	
	}
	

}
