/*
1. Each row of the file StudentProfile.csv represents an object,
an instance of a class that could be called StudentProfile.

2. List all the variables stored in the csv profile: 
Name, Age, Class Year, Dorm, Have an on campus job?, Dean

3. Next to each variable, list the most appropriate type:
Name - String
Age - int
Class Year - int
Dorm - String
Have an on campus job? - Boolean
Dean - String
*/



package prelab;

public class StudentInformation {
	
	// Instance variables
	private String studentName;
	
	private int age;
	
	private ClassYear classYear;
	
	private Dorm dorm;
	
	private Dean dean;
	
	public enum ClassYear {FIRST_YEAR, SOPHOMORE, JUNIOR, SENIOR, GRADUATED};
	//public classYear standing;

	public enum Dorm {BARCLAY, TRITTON, JONES, GUMMERE, APARTMENTS, KIM, LEEDS,
	LLOYD, QHOUSE, DRINKER, BCC, COMFORT, LUNT};

	public enum Dean {MICHAEL_ELIAS, KATRINA_GLANZER, MARTHA_DENNEY, THERESA_TENSUAN,
	BRIAN_CUZZOLINA, KELLY_WILCOX};
	
	// Getters
	public String getStudentName() { return studentName; }
	
	public int getAge() { return age; }
	
	// Constructors											
	public StudentInformation(String studentName, int age, ClassYear classYear, Dorm dorm, Dean dean)
	{
	this.studentName = studentName;
	this.age = age;
	this.classYear = classYear;
	this.dean = dean;
	this.dorm= dorm;
	}
	
	public StudentInformation(String studentName, String age)
	{
	this.studentName = studentName;
	this.age = Integer.parseInt(age);
	}
	
	// Overriding toString method
	@Override
	public String toString() {
		return "Name: " + getStudentName() + "\n" +
		" Age: " + Integer.toString(getAge());
	}
	

	

//public String getAge() {
	//age.toString()
// Prelab Question 8



// object constructor (Prelab Question 6)

	
// Prelab Question 9
//public String studentInformation(String old, String name) 


//public String 
}







