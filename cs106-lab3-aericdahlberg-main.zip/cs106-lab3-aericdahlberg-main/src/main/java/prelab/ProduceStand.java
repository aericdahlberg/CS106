package prelab;

/*
 * Starter code that could be commented better in the future.
 */

import java.util.ArrayList;

public class ProduceStand implements Comparable<ProduceStand>{
	// fields
	private ArrayList<String> produceNames;
	private double totalAsset;
	private String standName;
	
	// constructor
	public ProduceStand(ArrayList<String> namesOfProduce, double assetsTotal, String name) {
		produceNames = namesOfProduce;
		totalAsset = assetsTotal;
		standName = name;
		
	}
	public int compareTo(ProduceStand other) {
		if (other.getTotalAsset()<totalAsset){
			System.out.println("greater");
			return 1 ;	
		}
		else if (other.getTotalAsset()>totalAsset){
			System.out.println("less than");
			return -1 ;		
		}
		else {
			System.out.println("equal assets");
			
			if (this.standName.compareTo(other.standName) < 0) {
				System.out.println("before");
				return 1;
			
			}
			
			else if (this.standName.compareTo(other.standName) > 0) {
				System.out.println("after");
				return -1;
			}
			else {
				if (getNumItems() > (other.getNumItems())) {
					return 1;
							
				}
				else if (getNumItems() > (other.getNumItems())) {
					return -1;
				}
				else {
					return 0;
				}
			}
		
	
	

		}
			
	}
	// getter methods
	public double getTotalAsset() { return totalAsset; }
	public String getStandName() { return standName; }
	public int getNumItems() { return produceNames.size(); }
	
	@Override
	public String toString() {
		return standName + " is worth $" + totalAsset + " and sells " + produceNames.toString();
	}
}

