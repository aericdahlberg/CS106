package prelab;
//q line57/
import java.util.ArrayList;
import java.util.Arrays;

public class Main {

	public static void main(String[] args) {
		System.out.println("Given command line arguments: \n" + Arrays.toString(args));
		
		// Variables to keep track of the produce
		ArrayList<String> vegetableNames = new ArrayList<String>();
		ArrayList<String> fruitNames = new ArrayList<String>();
		ArrayList<String> spiceNames = new ArrayList<String>();
		double totalAssetVegetable = 0;
		double totalAssetFruit = 0;
		double totalAssetSpice = 0;
		
		// TODO: parse the command line arguments!
		
		// TODO: create an object of each type and print it!
		
		// TODO: after implementing comparable, compare the objects above! 
		
		String orange = "orange";
		String lemon = "lemon";
		
		
		
		
		////////// question here
		///how do i do this if statement
		
		System.out.println("lemon compared to orange: " + lemon.compareTo(orange));
		System.out.println("lemon compared to lemon: " + lemon.compareTo(lemon));
		
		for (int i=0; i< args.length; i++){
		
			if (args[i].equals("-f")) {
				fruitNames.add(args[i+1]);
				totalAssetFruit += (Double.parseDouble(args[i+2]));
				System.out.println (totalAssetFruit);
				System.out.println (fruitNames);
				
			}
			if (args[i].equals("-v")) {
				vegetableNames.add(args[i+1]);
				totalAssetVegetable = totalAssetVegetable + (Double.parseDouble(args[i+2]));
				System.out.println (totalAssetVegetable);
				System.out.println (vegetableNames);
			
			
			} 
			if (args[i].equals("-s")) {
				spiceNames.add(args[i+1]);
				totalAssetSpice = totalAssetSpice + (Double.parseDouble(args[i+2]));
				System.out.println (totalAssetSpice);
				System.out.println (spiceNames);
			
			}
			
		}								//why do i need a new here
		ProduceStand fruitStand = new ProduceStand(fruitNames, totalAssetFruit, "Fruit Stand");
		fruitStand.toString();
		
		ProduceStand spiceStand = new ProduceStand(spiceNames, totalAssetSpice, "Spice Stand");
		spiceStand.toString();
		
		ProduceStand vegetableStand = new ProduceStand(vegetableNames, totalAssetVegetable, "Vegetable Stand");
		vegetableStand.toString();
		
		
		System.out.println(fruitStand.toString());
		System.out.println(spiceStand.toString());
		System.out.println(vegetableStand.toString());
		System.out.println(vegetableStand.compareTo(spiceStand));
		
	}
	
	
}









