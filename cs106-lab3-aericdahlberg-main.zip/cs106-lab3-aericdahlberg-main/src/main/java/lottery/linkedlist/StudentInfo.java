package lottery.linkedlist;

public class StudentInfo  implements Comparable<StudentInfo>{

/*
 * creating instance variables for all the categories of students, the initials, the year (1,2,3 or 4)
 * major, minor (in an int array), which we then can multiply by other values in a separate array from 
 * courseInfo to find their addition to points, and then boolean values for institution and lotteried
 * 
 * also not we create a points variable which we will use to add up points later on
 */
	
	String initials;
	int year;
	int[] majors = {0,0,0};
	int[] minors = {0,0,0}; 
	boolean institution;
	boolean lotteried;
	
	int points;
	
	
	/*
	///method of taking a student and their information from the csv file and putting it
	///into a method which puts the information into the right types we need for our 
	 * instance variables above, for example...
	 * if major is n, the method will change int[] major = {1,0,0} from the origional 
	 * 
	 */
	public StudentInfo (String initials, String year, String majors, 
			String minors, String institution, String lotteried) {
		
		this.initials = initials;
		this.year = Integer.parseInt(year);
		
		/// for loop to place major and minor values into int array majors, and int array minors
		for (String major: majors.split("/")) {
			
	
			if (major.compareTo("H")==0) {
				this.majors[0]=1;
			}			
			else if (major.compareTo("N")==0) {
				this.majors[1]=1;
			}
						
			else {
				this.majors[2]=1;
			
			}
		}
		for (String minor: minors.split("/")) {
			
			
			if (minor.compareTo("H")==0) {
				this.minors[0]=1;
			}			
			else if (minor.compareTo("N")==0) {
				this.minors[1]=1;
			}
						
			else {
				this.minors[2]=1;
			
			}
		}
		
		/*
		 * put bool value into institution
		 */
		if ((institution.equals("HC") || institution.equals("BMC"))) {
			this.institution = true;	
		}
		else {
			this.institution =false;
		}
		
		/*
		 * put a bool value into lotteried
		 */
		if (lotteried.equals("Yes")){
			this.lotteried = true;
		}
		else {
			this.lotteried = false;
		}
	}
	
	/*
	 * this is the method that adds up all the points for each part of the 
	 */
	
	public void pointcalc(CourseInfo info) {
		/*
		 * this calls a getmethod in CourseInfo java to see what points are given for the year
		 */
		int count= 0;
		count+=info.getYearPreference()[year-1];

		///for major, since major is a int array with 3 places, we can add each multiplication of points from 
		///each major and the points attributed from that major, again using a .get from CourseInfo
		int[] majorPreferences= info.getMajorPreference();
		for (int i=0; i<majorPreferences.length; i++)
			count+= majorPreferences[i] * this.majors[i];
		
		
		/// for minor. since minor is a int array with 3 places, we can add each multiplication of points from 
		///each minor and the points attributed from that minor, again using a .get from CourseInfo
		int[] minorPreferences= info.getMinorPreference();
		for (int i=0; i<minorPreferences.length; i++)
			count+= minorPreferences[i] * this.minors[i];
		
		/// for BICO using bool for institution, so if true the rest runs
		if (institution)
			count += info.getBiCoPreference();
		
		/// for lotteried, using bool for lotteried, so if true the rest runs
		if (lotteried)
			count+= info.getPreviousPreference();
		//set the points= the count
		this.points=count;
	}
	
	// getter for points
	public int getPoints() {
		return points;
	}
	
	
/*
 * compareTo function, 1 is returned if it belongs before the other object, and -1 is returned if it belongs after
 */
	@Override
	public int compareTo(StudentInfo other) {
		if (points>other.getPoints()){
			return 1 ;
		}
		else if (points<other.getPoints()){
			return -1 ;
		}
		
		else {
			if (this.initials.compareTo(other.initials) > 0) {
				return 1 ;
			
			}
			else {
				return -1;
			}
		}
	
			
			
			
	}
	
	
	
}
