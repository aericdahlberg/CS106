package lottery.linkedlist;


public class StudentNode {
	private StudentInfo element;
	private StudentNode prev;
	private StudentNode next;
	 
	
	
	/*
	 * first constructor to create StudentNodes
	 */
	public StudentNode(StudentInfo e, StudentNode p, StudentNode n) {
		element=e;
		prev=p;
		next=n;
	}


	/**
	 * @return the element
	 */
	public StudentInfo getElement() {
		return element;
	}


	/**
	 * @param element the element to set
	 */
	public void setElement(StudentInfo element) {
		this.element = element;
	}


	/**
	 * @return the prev
	 */
	public StudentNode getPrev() {
		return prev;
	}


	/**
	 * @param prev the prev to set
	 */
	public void setPrev(StudentNode prev) {
		this.prev = prev;
	}


	/**
	 * @return the next
	 */
	public StudentNode getNext() {
		return next;
	}


	/**
	 * @param next the next to set
	 */
	public void setNext(StudentNode next) {
		this.next = next;
	}
}
