package lottery.linkedlist;

import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

import com.opencsv.CSVReader;

import propublica.datadesign.SampleCompasProfiles;

public class Main {
	
	public static void main(String[] args) {
		// TODO: Output the lottery result based on command line arguments!
	
		CSVReader reader;
		ArrayList<String[]> myEntries;
		try 
		{
			// Code copied from lab tasks to read in the csv data
			reader = new CSVReader(new FileReader("lottery-csh231.csv"));
			myEntries = new ArrayList<String[]>(reader.readAll());
			reader.close();
		
			CourseInfo course = new CourseInfo(myEntries.get(0));
			System.out.println(course.getYearPreference()[3]);
			
			StudentInfo fullDataset = new StudentInfo();
			fullDataset.add(myEntries);
			System.out.println(fullDataset.toString());
		
		}
		catch (IOException e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	
	
	
	// TODO: make sure you test your work as you go!
	}
}
