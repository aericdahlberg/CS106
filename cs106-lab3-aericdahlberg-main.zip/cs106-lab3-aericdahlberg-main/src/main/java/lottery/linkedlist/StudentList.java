package lottery.linkedlist;

public class StudentList {
	
	
	
/*
 * instance variables, head and tail are our sentinals,
 * size is the size of the list
 * 
 */
StudentNode head;
StudentNode tail;
int size;
CourseInfo info;


/*
 * creating the linked list, at least the sentinals, (head and tail)
 * setting size to 0
 */
public StudentList(CourseInfo info) {
	head = new StudentNode (null, null, null);
	tail = new StudentNode (null, head, null);
	head.setNext(tail);
	size = 0;
	this.info = info;
	
	
	
}


/*
 * getters and isEmpty is a bool call we call in the function to see if the list is empty
 */
public int getSize() {
	return size;
}
	
public boolean isEmpty() {
	return size == 0;
}
		

/*
 * addBeginning, new method to add a new node to the list if there are no other nodes in the list already, will be called by 
 * main add method if list is empty
 */
public void addBegining(StudentInfo person) {
	StudentNode newnode = new StudentNode(person, head, head.getNext());
	head.setNext(newnode);
	newnode.getNext().setPrev(newnode);
	size++;
}
		

/*
 * addEnding is a method to place a node down at the end of the list, before tail. Called by add Method when person
 * has lower points then anything else in the list
 */
public void addEnding(StudentInfo person) {
	StudentNode newnode = new StudentNode(person, tail.getPrev(), tail);
	tail.setPrev(newnode);
	newnode.getPrev().setNext(newnode);
	size++;

}

/*
 * main method of sorting new nodes into the list.
 * If isEmpty, then we call the addBegining method,
 * For method to go down linked list and add it if it has a greater point value and if the points are =, then by alphabetical order
 * addBegining, and the for loop, increases size by 1 each iteration
 * if the for loop doesn't go through, we add the new node at the end thorugh addEnding method
 */
public void add(StudentInfo person) {
	StudentNode newnode = new StudentNode(person, null, null);
	if (isEmpty()) {
		addBegining(person);
		return;
	}
	StudentNode currentNode = head.getNext();
	for (int i=0; i<size; i++) {
		if (person.compareTo(currentNode.getElement())>0 ) {
			newnode.setNext(currentNode);
			newnode.setPrev(currentNode.getPrev());
			currentNode.setPrev(newnode);
			newnode.getPrev().setNext(newnode);
			size++;
			return; 
			
		}
		currentNode = currentNode.getNext();
	}
	addEnding(person);
}
}
