## CS 106 Lab 3 - Course lottery simulation using linked list
## Deadline - Midnight, March 19, 2021

Name: Eric Dahlberg

Number of Late Days Using for this lab: 1

---
## Suggestions
1. Read the assignment at least twice -- understanding the requirement
2. Revise the relevant concepts
3. Sketch a proper plan -- design
4. Implementation-- write the code
5. Debug and test-- conduct unit testing i.e. test each peice separately and then conduct integration testing (everything together)
6. Write the report

### Writeup

1. Describe the process you followed to arrive at the solution.
I tried to hash out the idea of what I wanted. First I wanted to use the CSV reader to take information from the form and run it so I could fill up my own instance variables with data of the right type, (not string). I used a studentInfo method to do this. Then I calculated the points based off of the students attributes and added them all up. So each student had a number of points and could be sorted. Then the arduous process of trying to sort them would be accomplished by a double linked list. I had to create the list, create sentinals and then create a sorting mechanism to do the rest. Then I would sort each student by their point value as I added them to the list one by one. 

2. Describe your StudentNode class design. What variables and methods do you have in it?
I have 3 variables in this design. Element, prev and next. These prev and next are of the type StudentNode and element is of the type StudentInfo. This is so i can assign element a value for points, and sort it by looking at the previous and next item on the linked list. 
Then I have a bunch of getters and setters so when I want to add something into the list I can reset the way the nodes are linked. 

3. How do you keep the linked list in sorted order?
I use 3 methods of adding nodes into the list. 1) if the list is empty, add it and increase the size by one. 2) add something in the middle, which is acomplished by finding the place where the points are greater than the things around it. 3) if the points of an node are less than all the other nodes, adding it to the back of the list.
I go through the list and sort them all based on that

4. Describe your implementation of each part of the optional extension done, if any.

---

### Lab questionnaire

(None of your answers below will affect your grade; this is to help refine lab
assignments in the future)

1. Approximately, how many hours did you take to complete this lab? (provide
  your answer as a single integer on the line below)
  more than 15, honestly not sure

2. How difficult did you find this lab? (1-5, with 5 being very difficult and 1
  being very easy)
  I did not feel prepared for this lab at all. It was the hardest assignment I have ever done and I still didn't finish it even with extra time. 

3. Describe the biggest challenge you faced on this lab:

Using the linked list, not knowing what code to use or what information to draw from. I feel the hardest part of this class is not knowing how to put your thoughts from paper to code and I had no idea where to begin.  
