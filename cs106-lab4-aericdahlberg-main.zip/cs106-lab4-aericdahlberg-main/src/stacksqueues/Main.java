package stacksqueues;

public class Main {

	public static void main(String[] args) {
		// TODO: you should add tests for your implemented LinkedStack and
		// ArrayDeque here. We suggest that you group these tests together into
		// two separate methods that you call from this main method.
		
		
		
		//test all methods in linkedstack
		
		//beginning of linkedstack tests...
		//creating a new stack called burry
		LinkedStack <Integer> burry = new LinkedStack<Integer>();
//		burry.pop(); // makes an error
//		burry.peek(); //makes an error
		
//		//pushing integers
//		burry.push(3);
//		burry.push(4);
//		System.out.println(burry.peek());
//		//printing integer to see if pop works
//		System.out.println(burry.pop());
//		//checking for these when burry has items
//		System.out.println(burry.size());
//		System.out.println(burry.isEmpty());
//		System.out.println(burry.pop());
//		//checking for these when burry is empty
//		System.out.println(burry.size());
//		System.out.println(burry.isEmpty());
//		burry.push(10);
//		burry.push(20);
//		burry.push(30);
//		burry.push(40);
//		System.out.println(burry.toString());
//		//check new list for String to see if E works
		LinkedStack <String> barry = new LinkedStack<String>();
		//pushing integers
		barry.push("This is");
		barry.push("Eric");
		//printing integer to see if pop works
		System.out.println(barry.pop());
		//checking for these when burry has items
		System.out.println(barry.size());
		System.out.println(barry.isEmpty());
		System.out.println(barry.pop());
		//checking for these when burry is empty
		System.out.println(barry.size());
		System.out.println(barry.isEmpty());
		barry.push("Hi");
		barry.push("");
		barry.push("yes");
		barry.push("no");
		System.out.println(barry.toString());
/// end of linkedstack tests		
		
		
		
		
		
		
		
		
		
///beginning of arraydeque tests
		
		ArrayDeque bigarr = new ArrayDeque();
		ArrayDeque smallarr = new ArrayDeque(7);
		
//// random checks to see if adds work, and if removes work, and if isEmpty, size, first and last work
//		bigarr.addFirst(5);
//		bigarr.addFirst(20);
//		bigarr.addLast(200);
//		bigarr.addLast(1);
//		System.out.println(bigarr.isEmpty());
//		bigarr.addFirst(5);
//		System.out.println(bigarr.toString());
//		System.out.println(bigarr.size());
//		System.out.println(bigarr.first());
//		System.out.println(bigarr.last());
//		System.out.println(bigarr.removeFirst());
//		System.out.println(bigarr.removeLast());
//		System.out.println(bigarr.removeFirst());
//		System.out.println(bigarr.removeFirst());
//		System.out.println(bigarr.removeFirst());
	//	System.out.println(bigarr.removeFirst());   	:EmptyQueueException
	//this checks out
	// we have used  addLast and addFirst and the system works for those
		
		
		
////to test toString when array is wrapped around
//		smallarr.addFirst(7);
//		System.out.println(smallarr.toString());
//		
//		smallarr.addFirst(6);
//		smallarr.addFirst(5);
//		smallarr.addFirst(4);
//		smallarr.addFirst(3);
//		smallarr.addFirst(2);
//		smallarr.addFirst(1);
//		smallarr.addFirst(5);   ///FullQueueException
//		System.out.println(smallarr.toString());
		
//to test toString when array is "normal" or in a row
//		smallarr.addLast(1);
//		smallarr.addLast(2);
//		smallarr.addLast(3);
//		smallarr.addLast(4);
//		smallarr.addLast(5);
//		smallarr.addLast(6);
//		smallarr.addLast(7);
//		System.out.println(smallarr.toString());
//		
		
		
		
		
		
	
		
				
	
	}
	
	
}
