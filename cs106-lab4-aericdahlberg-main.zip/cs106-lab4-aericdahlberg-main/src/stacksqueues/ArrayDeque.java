package stacksqueues;

/**
 *  Starter code for creating an array and a way to fill the array
 *  from the start, end, and take away values from both,
 *  the array wrapps around itself
 *
 *  @author Eric Dahlberg
 *  @version done
 */

public class ArrayDeque <E> implements Deque <E>{
	
	private E[] data; 
	private int first;
	private int size;
	
	// constructors which create array lists of either size 1000 (if no input), or size (input)
	public ArrayDeque() {
		data= (E[]) new Object[1000];};
	public ArrayDeque(int capacity) {
		data= (E[]) new Object[capacity];
	}

	
	/*
	 * add first inputs an element to a list, there are 4 cases here,
	 * 1. list is full, FullQueueException
	 * 2. size is 0, so first becomes 0
	 * 3. first is 0 so we need to wrap around to the end of the arraylist
	 * 4. first is in the middle and we just add this.first before  first
	 */
	@Override
	public void addFirst(E element) throws FullQueueException {
		// TODO Auto-generated method stub
		if (size== data.length) throw new FullQueueException();
		else if (size == 0 ) {
			first = 0;
			data[0] = element;
			size++;     
		}	
		else if (first == 0) {
			data[data.length -1] = element;
			first = data.length -1;
			size++;
		}
		else {
			data[first-1] = element;
			first= first -1;
			size++;
		}
	}

	
	
	/*
	 * add last adds an element to the last of the list, 2 cases
	 * 1. list is full, FullQueueException
	 * 2. available placing = (first+size)%data.length which will find an open slot (not affecting first variable)
	 */
	@Override
	public void addLast(E element) throws FullQueueException {
		// TODO Auto-generated method stub
		if (size== data.length) throw new FullQueueException();
		int avail = (first+size)%data.length;
		data[avail] = element;
		size++;	
	}
	
	
/*
 * removes first element from a list, 4 cases
 * 1. list is empty EmptyQueueException
 * 2. size is 1 so get rid of the one element in the list and don't change first
 * 3. first is at the end of the array so we need to wrap around to the beginning of the array and say first=0
 * 4. any other scenario where first will be removed and the new first will be the slot to the 
 * right of the original first
 */
	@Override
	public E removeFirst() throws EmptyQueueException {
		// TODO Auto-generated method stub
		if (size== 0) throw new EmptyQueueException();
		else if (size == 1 ) {
			E removed = data[first] ;
			data[first] = null;
			size--;
			return removed;
		}
		else if (first == data.length-1){
			E removed = data[data.length -1];
			data[data.length -1] = null;
			first = 0 ;
			size--;
			return removed;
		}
		
		else {
			E removed = data[first];
			data[first] = null;
			first= first+1;
			size--;
			return removed;
		}
	}

	
	
	/*remove last, 2 cases
	 * 1. list is empty EmptyQueueException
	 * 2. id the last, which is (first+size-1)%data.length.
	 * I took this equation and realized (first+size)%data.length gives you 
	 * an open slot, not the last element, so the -1 finds the last element,
	 * even if there is only one element this still works. 
	 * then remove that data[last]
	 */
	@Override
	public E removeLast() throws EmptyQueueException {
		// TODO Auto-generated method stub
		if (size== 0) throw new EmptyQueueException();
		int last = ((first+size-1)%data.length);
		E removed = data[last] ;
		data[last] = null;
		size--;
		return removed;
	}

	/*
	 * reterns the first element in the list
	 * exception when list is empty
	 */
	@Override
	public E first() throws EmptyQueueException {
		// TODO Auto-generated method stub
		return data[first];
	}
	/*
	 * 1.reterns the last element in the list
	 * exception when list is empty
	 * 2.id the last, which is (first+size-1)%data.length.
	 * I took this equation and realized (first+size)%data.length gives you 
	 * an open slot, not the last element, so the -1 finds the last element,
	 * even if there is only one element this still works.
	 */
	@Override
	public E last() throws EmptyQueueException {
		// TODO Auto-generated method stub
		int last = ((first+size-1)%data.length);
		return data[last];
	}
/*
 * returns size
 */
	@Override
	public int size() {
		// TODO Auto-generated method stub
		return size;
	}

	/*
	 * boolean value for whether list is empty or not...
	 */
	@Override
	public boolean isEmpty() {
		return (size == 0);
	}
	
	
	/* returns a string of the elements in a list, there are 3 cases here,
	 * we use a compiler, to compile all the string together
	 * we don't print all elements in the list, but find first and print from 
	 * first to last because we know that first and last will all have elements
	 * between them
	 * 
	 * 1. size is 1 so we just need to print data[first] 
	 * 2. first is < last, so we need one for loop since the first will eventually 
	 * lead to the last element
	 * 3. first is > last, so this means that the elements are wrapped around the 
	 * Arraylist. So we have 2 for loops, printing first to, data.length-1 
	 * (size of the array, or i<data.length), and then the other printing from 0 to 
	 * last (i<last+1).
	 */
	public String toString() {
		String compile = "(";
		int last = ((first+size-1)%data.length);
		if (size == 1) {
			compile += data[first].toString();
			return compile + ")";
		}	
		if (first < last) {
			for (int i =first; i<last+1; i++) {
				if (i!=last) {compile = compile + data[i].toString() + ", ";}
				else {compile = compile + data[i].toString() + ")";}
			}		
		return compile;
		}
		else{
			for (int i =first; i<data.length; i++) {    // check to see if avail+1 is right
				compile = compile + data[i].toString() + ", ";
			}
			for (int i =0; i<last+1; i++) {    // check to see if avail+1 is right
				if (i !=last) {compile = compile + data[i].toString() + ", ";}
				else {compile = compile + data[i].toString() + ")";}
			}
			return compile;
		}
	}
}