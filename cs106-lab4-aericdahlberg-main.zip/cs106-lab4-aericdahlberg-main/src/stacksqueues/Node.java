package stacksqueues;
/*
 * this class is made up of a node. The node takes any value, int, string, etc. 
 * Nodes have 2 parameters initialized in this class, element and next.
 * element could be any E, 
 * next is the next node with anything as its element
 */
public class Node <E> {
	
	private E element;
	private Node <E> next;
		
		
/*
 * this class creates a node where the imput is e and n, e becomes the element of 
 * type anything,
 * n is a node
 */

	public Node(E e , Node <E> n) {
		element= e;
		next=n;
	}


	/**
	 * @return the element of a node
	 */
	public E getElement() {
		return element;
	}


	/**
	 * @param sets the element of anode to something else
	 */
	public void setElement(E element) {
		this.element = element;
	}


	/**
	 * @return returns the next node a node is connected to 
	 */
	public Node <E> getNext() {
		return next;
	}


	/**
	 * @param sets the next node to a different node. 
	 */
	public void setNext(Node <E> next) {
		this.next = next;
	}
}



