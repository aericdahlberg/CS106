package stacksqueues;

/**
 *  Starter code for creating a stack that holds nodes. 
 *
 *  @author Eric Dahlberg
 *  @version done
 */
import java.util.EmptyStackException;

/*
 * first thing i do is create a node class, define the things i will string together.
 * I define Node as anything or Node (<E>). Then I set the main method as element
 * and next. So each node has a value and is connected to something else. Now I make 
 * setters and getters to find and change those values
 * 
 * E is one datatype, whatever comes in 
 */
public class LinkedStack <E> implements Stack<E>{
	
	private Node<E> top;
	


	private Node<E> next;
	private int size;
	

	
	
	


	/**
	 * @param size the size to set 
	 * My getters and setters for this class, 
	 * size, top 
	 */
	public void setSize(int size) {
		this.size = size;
	}
	
	public Node <E> getTop() {
		return top;
	}
	
	public void setTop(Node<E> top) {
		this.top = top;
	}
	
	
	public int size() {
			// TODO Auto-generated method stub
		return size;
	}

/*
 * constructor to create the stack,
// I set top as a node without any value or pointing to another thing
 * i set size to zero because there is nothing in the stack
*/

	public LinkedStack() {
		top = new Node<E> (null, null);
		size = 0;
	}
		
	// this first one puts elements into the stack
	// element is turned into a node, ( new Node (newObject, null))
	// if the stack is empty it sets the top to new node
	// if the stack is not empty it sets the newnode's (next) to top and then 
	//sets the top to new node
	//increases size each time
	public void push (E newObject){
		Node <E> newNode = new Node (newObject, null);
		if (size == 0) {
			top = newNode; 
			size ++;
		}
		else {
			newNode.setNext(top);
			top = newNode;
			size ++;		
		}	
	}
	
	/*
	 * bool value if size is 0 or not
	 */
	
	public boolean isEmpty(){
		if (size == 0){
			return true;
		}
		else {
			return false;
		}
	}
	

	
	
	
	
	
		/*
		 * pops a node out of a stack (removes the top node)
		 * returns its element
		 * makes top the next node in the stack
		 * decreses size by one
		 */
	public E pop() throws EmptyStackException{
		if (size == 0) {
			throw new EmptyStackException();
		
		}
		else {
			E popp =top.getElement();
			top = top.getNext();
			size= size - 1;
			return popp;
			///should this be top
			
		}
	}
	
	
	
	/*
	 * first make a pointer for our origional stack
	 * make a string compiler called outcome, (starting with "(")
	 * the first while loop runs if the origional stack is not empty
	 * it sets top as a new node in the list and pushes all the 
	 * elements into a new stack called reverse...
	 * when the pointer = null, which it will eventually as it goes through
	 * the stack, 
	 * 
	 * Next while loop uses reverse.size to get the size and while it does
	 * not = 0 we go on,
	 * first if statement is when size =1 just so we can print the last element out 
	 * without a comma and space,  "14" instead of "14, "
	 * else is the other statement which adds comma and string
	 * the other code pops the top element out, converts it to string and adds it 
	 * to the string compliler, outcome
	 * 
	 */
	public String toString (){
		
		LinkedStack <E> reverse = new LinkedStack<E>();
		Node <E> pointer = top;
//		Node <E> pointer2 = reverse.top;
		String outcome= "(";
		//for (Node <E>)//
		while (pointer != null) {
			reverse.push(pointer.getElement());
			pointer = pointer.getNext();
			 
		}
		while (reverse.size() != 0){
			if (reverse.size() == 1) {String parts = reverse.pop().toString(); outcome = outcome + parts;}
			else { 
				String parts = reverse.pop().toString()+ ", " ;
				outcome = outcome + parts;
			}
			
		}
		outcome = outcome + ")";
		return outcome;
	}



/*
 * looks at the top element of a stack and reterns the top element, unless the stack is empty
 */

	@Override
	public E peek() throws EmptyStackException {
		// TODO Auto-generated method stub
			if (size == 0){
				throw new EmptyStackException();
			}
			else {
				return top.getElement();
			}	
		}



		
	
	
	
}
