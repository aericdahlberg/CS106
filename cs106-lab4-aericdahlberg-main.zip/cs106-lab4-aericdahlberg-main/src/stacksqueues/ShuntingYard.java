package stacksqueues;

/**
 *  Implements the shunting yard algorithm.
 *  See http://en.wikipedia.org/wiki/Shunting-yard_algorithm
 */
public class ShuntingYard {

}
