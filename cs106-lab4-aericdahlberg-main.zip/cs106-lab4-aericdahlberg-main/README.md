# CS106 Lab 4: Stacks and Queues
## Due: April 2nd, Midnight

Name: Eric

Number of Late Days Using for this lab: NONE: Rajesh approved turning in late due to eclipse error

---
## Suggestions
1. Read the assignment at least twice -- understanding the requirement
2. Revise the relevant concepts
3. Sketch a proper plan -- design
4. Implementation-- write the code
5. Debug and test-- conduct unit testing i.e. test each peice separately and then conduct integration testing (everything together)

### Writeup

1. Describe the process you followed to arrive at the solution.
I looked at the book to refresh my understanding of the material. I then created a basic idea on paper of what my processes would be for each part and then wrote the code. 

2. Describe your implementation of each part of the assignment in a layman term.
I realized that the first part needed nodes and a stack so i made a node class and a stack class. Then I created fields for both and implamented the node class within the stack class. This allowed me to create nodes and add them to the stack. 
In the second part I needed to create an array list so I created two constructors, then I made cases where the first and last term were in different parts of the arraylist and methods that would add or subtract terms depending on where first and last is in the arraylist. 
The last part I realized I needed to utilize bases. I implimented the scanner and pushed every number onto the stack, while popping two numbers of the stack when there was an opperation, computing the operation, and adding it back to the stack. There were many base cases for the different operations. 

---

### Lab questionnaire

(None of your answers below will affect your grade; this is to help refine lab
assignments in the future)

1. Approximately, how many hours did you take to complete this lab? (provide
  your answer as a single integer on the line below)
  8

2. How difficult did you find this lab? (1-5, with 5 being very difficult and 1
  being very easy)
  4

3. Describe the biggest challenge you faced on this lab
Not being able to get help for the last error I had in my lab. The TA's couldn't help me and I didn't get the support I needed to fix it. Part 3 was definitly the most challenging because there was the least instruction as well. The concept was easy, but the proper way of implamenting the code was a little tricky. I definitly needed a little more support to finish. 

