## CS 106 Lab 5 - Binary Trees - Back to pair programming

Add your name [here](https://docs.google.com/spreadsheets/d/1LHZOr9Jjvd6Ps-9_n5Wk4FLxz_cNuv8qAHpRjL71lo0/edit?usp=sharing), if you have not added. (The pairs MUST NOT be the same as previous pairs)

Pair programming resources: 

[Watch this video](https://drive.google.com/file/d/14buip5KWRc0963UfReaJCfKsG5mapiBW/view) AND
[Read this document](https://drive.google.com/file/d/1UFoy62RRCVqUbdS_lzwlOtkgu8eL_NjA/view?usp=sharing)

Member1 name: Mai-Anh Nguyen

Member2 name: Eric Dahlberg

Number of Late Days Using for this lab: 0
(as long as one of you have non-penalty extension, the pair can use it, just note that here)

Any special requet/approval from the professors:

---

### Analysis Questions

1. In Lab 3 we used insertion sort with Linked Lists to gradually build up
a sorted list of Students. If the total number of Students is n, what was the big-O runtime
of this algorithm? Briefly explain your answer.

  In Lab 3, whenever a new Student is required to be added to the linked list, we need to go over each Student in the current list and compare the new Student's point with every Student's point until finding the suitable position to add the new Student to the list. In the worst-case scenario if the Student is inserted at the end of the list, there will be n iterations. Therefore, the runtime of this insertion method is O(n). The insertion method can only add 1 Student to the list, which means that if we want to add n Students to the linked list, we need to call this insertion method n times. Therefore, the overall runtime for this algorithm is O(n^2).

2. In this assignment (Lab 5) we used insertion sort with a Binary Tree, then
used a tree traversal to obtain a sorted list of candidates. If the total
number of candidates is n, what is the big-O runtime of this algorithm? Briefly 
explain your answer.

  In Lab 5, to add a candidate to the binary tree, we have to compare the new candidate's last name with the tree root's last name first to see which one comes before or after, so we can narrow the whole process to either the left or right half. Then, we repeatly check by keep dividing the searching process into half until we find the suitable position, then we add the candidate to the tree. This insertion operation takes O(logn) runtime. However, this insertion method can only add 1 Canddiate to the tree, which means that if we want to add n Candidates, we need to call this insertion method n times. Therefore, the runtime for this insertion sort with a Binary Tree is O(nlogn). After that, when using a tree traversal to obtain a sorted list of candidates, we have to go over each element in the tree. If the total number of candidates is n, this will require n operations to traverse the whole tree, indicating that the runtime for tree traversal is O(n). Overall, the big-O runtime of this algorithm is O(nlogn + n). Because n is smaller than nlogn, we ignore n. Hence, the big-O runtime is O(nlogn). 

### Pair programming log (will be graded)
You must fill the pair programming log. The format of the pair programming log can be downloaded [from here](https://drive.google.com/file/d/18iMHmSW7zJMoVBThzoKmvNCzPIA93lAR/view?usp=sharing). You can fill it, then use Add File-> Upload file options on your the repo using web browser. 

---

### Lab Questionnaire

(None of your answers below will affect your grade; this is to help refine lab
assignments in the future)

1. Approximately, how many hours did you take to complete this lab? (provide
  your answer as a single integer on the line below)
  
  Student 1: 3 hours
  
  Student 2: 3 hours

2. How difficult did you find this lab? (1-5, with 5 being very difficult and 1
  being very easy)
  
  Student 1: 2
  
  Student 2: 3

3. Describe the biggest challenge you faced on this lab:

  Student 1: I think the biggest challenge is applying recursion to implement size() and insert() methods.
  
  Student 2: ^^^ and also figuring out how to do the file reader again. 

4. Was the **VerifyFormat** file useful to you during testing?

  Student 1: Yes
  
  Student 2: Yes
