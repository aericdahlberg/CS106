/**
 * The LinkedBinaryTree class for lab 5
 * 
 * This class implements the BinaryTree interface by overriding methods insert,
 * getRootElement, size, isEmpty, toStringInOrder, toStringPreOrder, toStringPostOrder,
 * and a toString method for testing.
 * 
 * @author: Mai-Anh Nguyen, Eric Dahlberg
 * @version: April 19, 2021
 */

package polling.treesheaps;

/**
 * Class LinkedBinaryTree implements the BinaryTree interface, in which the generic
 * objects implement the compareTo method from the Comparable interface
 * @param <E> the type of data in the LinkedBinaryTree
 */
public class LinkedBinaryTree<E extends Comparable<E>> implements BinaryTree<E> {
	// instance variables
	private E rootData; // data of the root
	private LinkedBinaryTree<E> left; // left subtree
	private LinkedBinaryTree<E> right; // right subtree
	
	
	/**
	 * This constructor constructs an empty LinkedBinaryTree object. 
	 */
	public LinkedBinaryTree() {
		rootData = null;
		left = null;
		right = null;
	}
	
	/**
	 * This constructor constructs a new LinkedBinaryTree object with the value of 
	 * the tree root set as element. 
	 * @param element Data of the root of the tree
	 */
	public LinkedBinaryTree(E element) {
		rootData = element;
		left = null;
		right = null;
	}
	
	/**
	 * Insert an element into the tree
	 * @param element The element to be inserted
	 */
	@Override
	public void insert(E element) {
		if (rootData == null) {	
			// If the tree is empty, the element becomes rootData					
			rootData = element;
		} else if (element.compareTo(rootData) > 0) {
			// if the element is larger than rootData
			if (right == null){
				// Checks to see if right subtree is empty.
				// If it is, make right a new subtree by utilizing the second constructor with
				// parameter element to set element to the rootData of the right subtree
				right = new LinkedBinaryTree<E>(element);
			} else {
				// if the right subtree is not empty, recursively call insert method 
				right.insert(element); 
			}
		} else if (element.compareTo(rootData) < 0) {
			// if the element is smaller than rootData 
			if (left==null){
				// Checks to see if left subtree is empty.
				// If it is, make left a new subtree by utilizing the second constructor with
				// parameter element to set element to the rootData of the left subtree
				left = new LinkedBinaryTree<E>(element);
			} else {
				// if the left subtree is not empty, recursively call insert method 
				left.insert(element); 
			}
		} else {
			// if the element is already in the tree, it will replace the current element
			rootData = element;												
		}
	}

	/**
	 * Returns the element of the root 
	 * @return element at the root of the tree
	 */
	@Override
	public E getRootElement() {
		return rootData;
	}

	/**
	 * Recursively computes the number of elements in the tree
	 * @return number of elements in the tree
	 */
	@Override
	public int size() {
		int size = 0; // stores the size of the tree
		
		if (rootData == null) {
			// if the tree is empty, return 0
			return 0;
		} else {
			// if the tree is not empty
			if (left != null) {
				// if the left subtree is not empty, get the size of left subtree recursively
				// and add the value to size variable
				size += left.size();
			}
			
			if (right != null) {
				// if the left subtree is not empty, get the size of right subtree recursively 
				// and add the value to size variable
				size += right.size();
			}
			
			size += 1; // +1 for the root 
		}
		
		return size;
	}
	
	/**
	 * Tests whether the linked binary tree is empty
	 * we do this by just seeing if the rootData is empty or not
	 * we could also call size, but this method is a little easier
	 * @return true if the tree is empty, otherwise return false
	 */
	@Override
	public boolean isEmpty() {
		return rootData == null;
	}

	/**
	 * Implements in-order tree traversal
	 * @return a String of all tree elements according to in-order traversal 
	 */
	@Override												
	public String toStringInOrder() {
		String result = ""; // stores the String traversal
	
		// In-order traversal visits tree elements "from left to right"
		if (left != null) {
			// if the left subtree is not empty, recursively traverse the left subtree
			// and add all values to variable result
			result += left.toStringInOrder() + " ";
		}
	
		result += rootData; // adds the value of the root to variable result
	
		if (right != null) {
			// if the right subtree is not empty, recursively traverse the right subtree
			// and add all values to variable result
			result += " " + right.toStringInOrder();
		}
	
		return result;
	}

	@Override
	/**
	 * Implements pre-order tree traversal
	 * @return a String of all tree elements according to pre-order traversal 
	 */
	public String toStringPreOrder() {
		String result = ""; // stores the String traversal
		
		/* Pre-order traversal visits the root, then each left subtree.
		 * Once it cannot traverse to the left anymore, it visits the lowest rightmost element
		 * and adds that to result, gradually working its way back to the root. 
		 * Then it does the same process on the right of the subtree.
		 */
		result += rootData;  // starts by adding the rootData, the original node. to result
		
		if (left != null) {
			// if the left subtree is not empty, recursively traverse it
			// and add the values to the variable result
			result +=  " " + left.toStringPreOrder();
		}
		
		if (right != null) {
			// if the right subtree is not empty, recursively traverse it
			// and add the values to the variable result
			result += " " + right.toStringPreOrder();
		}
		
		// returns the string with all of the values from calling this method
		return result;	
		
	}

	/**
	 * Implements post-order tree traversal
	 * @return a String of all tree elements according to post-order traversal 
	 */
	@Override
	public String toStringPostOrder() {
		String result = ""; // stores the String traversal
		
		/* Post-order traversal recursively visits the subtrees rooted 
		 * at the children of the root first, and then visits the root.
		 */
		if (left != null) {
			// if the left subtree is not empty, recursively traverse the left subtree
			// and add all values to variable result
			result += left.toStringPostOrder() + " ";
		}
		
		if (right != null) {
			// if the right subtree is not empty, recursively traverse the right subtree
			// and add all values to variable result
			result += right.toStringPostOrder() + " ";
		}
		
		result += rootData; // adds the value of the root to variable result
		
		return result;
	}

	/**
	 * Overrides toString() method to print the tree in pre-order, in-order, and post-order traversals
	 * @return a String of all tree elements according to pre-order, in-order, and post-order traversals
	 */
	@Override
	public String toString() {
		return "Tree:\nPre:\t" + toStringPreOrder() + "\nIn:\t" + toStringInOrder() 
			 + "\nPost:\t" + toStringPostOrder();
	}

	/**
	 * Getter method for left subtree
	 * @return the left subtree 
	 */
	public LinkedBinaryTree<E> getLeft() {
		return left;
	}

	/**
	 * Setter method for left subtree
	 * @param left The left subtree to be set
	 */
	public void setLeft(LinkedBinaryTree<E> left) {
		this.left = left;
	}

	/**
	 * Getter method for right subtree
	 * @return the right subtree 
	 */
	public LinkedBinaryTree<E> getRight() {
		return right;
	}

	/**
	 * Setter method for right subtree
	 * @param left The right subtree to be set
	 */
	public void setRight(LinkedBinaryTree<E> right) {
		this.right = right;
	}
	
	
}
