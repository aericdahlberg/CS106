/* The main driver program for Lab 5
 * 
 * The goal of this lab is to practice with binary tree to 
 * work on polling data from the 2020 U.S. presidential election.
 * 
 * @author: Mai-Anh Nguyen, Eric Dahlberg
 * @version: April 19, 2021
 */

package polling.treesheaps;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import com.opencsv.CSVReaderHeaderAware;

public class Main {
	
    public static void main(String[] args) {
    	
    	// TODO: first create tests for your LinkedBinaryTree class (in a separate method below).
    	testBinaryTree(); // calls the testing method
    	System.out.println();
    
        // TODO: then read in the polling data from the given files and create a tree of candidates.
    	// creates an empty tree to store the polling data
    	BinaryTree<Candidate> pollTree = new LinkedBinaryTree<Candidate>(); 
    	
    	// Iterates over each filename input from the command line
    	for (int i = 0; i < args.length; i++) {
    		try {
    			// Reads in the data from the csv file and stores them in an ArrayList in which
        		// each row of data is an array of Strings
        		CSVReaderHeaderAware reader = new CSVReaderHeaderAware(new FileReader(args[i]));
        		ArrayList<String[]> myEntries = new ArrayList<String[]>(reader.readAll());
    			reader.close();
    			
    			// Goes over each String array in the ArrayList 
    			// to create Candidate objects based on the information on the rows
    			for (int j = 0; j < myEntries.size(); j++) {
    				Candidate candidate = new Candidate(myEntries.get(j));
    				pollTree.insert(candidate); // inserts each candidate to the pollTree
    			}
 
        	} catch (FileNotFoundException e) {
        		// handles FileNotFoundException
        		System.out.println("File not found!");
        	} catch (IOException e) {
        		// handles IOException
        		System.out.println("IOException!");
        	}
    	}
    	
		System.out.println(pollTree); // prints the final tree
    }
    
    /**
     * Tests methods in LinkedBinaryTree class
     */
    public static void testBinaryTree() {
    	// creates an empty Linked Binary Tree to store Integer values
    	BinaryTree<Integer> intTree = new LinkedBinaryTree<Integer>();
    	// insert numbers to the tree
    	intTree.insert(8);
    	intTree.insert(11);
    	intTree.insert(5);
    	intTree.insert(17);
    	intTree.insert(1);
    	intTree.insert(9);
    	intTree.insert(3);
    	System.out.println("Testing Integer tree");
    	// prints the size of the tree. Expected size: 7
    	System.out.println("size: " + intTree.size()); 
    	/* Prints all elements of the tree
    	 * Expected result:
    	 * Tree:
		 * Pre:		8 5 1 3 11 9 17
		 * In:		1 3 5 8 9 11 17
		 * Post:	3 1 5 9 17 11 8
    	 */
    	System.out.println(intTree);
    	System.out.println();
    	
    	System.out.println("\nTesting Character tree");
    	// creates an empty Linked Binary Tree to store Character values
    	BinaryTree<Character> letterTree = new LinkedBinaryTree<Character>();
    	// insert characters to the tree
    	letterTree.insert('A');
    	letterTree.insert('C');
    	letterTree.insert('G');
    	letterTree.insert('B');
    	letterTree.insert('D');
    	letterTree.insert('G'); // inserts a duplicated character
    	letterTree.insert('F');
    	letterTree.insert('E');
    	letterTree.insert('E'); // inserts a duplicated character
    	letterTree.insert('H');
    	letterTree.insert('I');
    	System.out.println("size: " + letterTree.size()); // prints the size. Expected size: 9
    	/* Prints all elements of the tree
    	 * Expected result:
    	 * Tree:
		 * Pre:		A C B G D F E H I
		 * In:		A B C D E F G H I
		 * Post:	B E F D I H G C A
    	 */
    	System.out.println(letterTree);
    }
}
