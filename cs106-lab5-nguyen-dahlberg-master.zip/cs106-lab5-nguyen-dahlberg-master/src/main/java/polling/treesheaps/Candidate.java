/**
 * The Candidate class for lab 3
 * 
 * This class represents the profile and polling data of each candidate 
 * taking part in the 2020 U.S. presidential election
 * 
 * @author: Mai-Anh Nguyen, Eric Dahlberg
 * @version: April 19, 2021
 */

package polling.treesheaps;

/**
 * Class Candidate implements the Comparable interface
 */
public class Candidate implements Comparable<Candidate> {
	// instance variables
	private String fullName; // full name of the candidate
	private String lastName; // last name of the candidate
	// percentage of people polled who said they would vote for that candidate
	private double percentage; 
	
	/**
	 * Constructs a new Candidate object. This constructor takes in a String array
	 * @param candidateProfile A String array that takes in information of a candidate
	 * candidateProfile[0]: represents the candidate's last name
	 * candidateProfile[1]: represents the candidate's full name
	 * candidateProfile[2]: represents the percentage of people who voted for that candidate
	 */
	public Candidate(String[] candidateProfile) {
		lastName = candidateProfile[0];
		fullName = candidateProfile[1];
		percentage = Double.parseDouble(candidateProfile[2]); // converts String to double
	}
	
	/**
	 * Compares 2 candidates based on their last names. 
	 * @param anotherCandidate Another candidate (with type Candidate) to be compared with 
	 * this candidate
	 * @return integer value representing the comparison based on the candidates' last names
	 * 0: two candidates have the same last names. This also could indicate that
	 * these two candidates are actually one person.
	 * -1: this candidate's last name is chronologically before anotherCandidate's last name,
	 * 1: this candidate's last name is chronologically after anotherCandidate's last name
	 */
	@Override
	public int compareTo(Candidate anotherCandidate) {
		if (lastName.compareTo(anotherCandidate.lastName) < 0) {
			// this candidate's last name is chronologically before anotherCandidate's last name
			return -1;
		} else if (lastName.compareTo(anotherCandidate.lastName) > 0) {
			// this candidate's last name is chronologically after anotherCandidate's last name
			return 1;
		} else {
			// two candidates have the same last names
			return 0;
		}
	}
	
	/**
	 * Overrides toString method to print the candidate's full name and percentage of votes 
	 * @return the formatted String "fullname:percentage"
	 */
	@Override
	public String toString() {
		return fullName + ":" + percentage;
	}
	
	/**
	 *  Getter method for full name
	 *  @return the full name (with type String) of the candidate
	 */
	public String getFullName() {
		return fullName;
	}
	
	/**
	 * Setter method for full name
	 * @param fullName Full name of the candidate to be set
	 */
	public void setFullName(String fullName) {
		this.fullName = fullName;
	}

	/**
	 *  Getter method for last name
	 *  @return the last name (with type String) of the candidate
	 */
	public String getLastName() {
		return lastName;
	}
	
	/**
	 * Setter method for last name
	 * @param lastName Last name of the candidate to be set
	 */
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	/**
	 *  Getter method for percentage
	 *  @return the percentage (with type double) of people who voted for the candidate
	 */
	public Double getPercentage() {
		return percentage;
	}
	
	/**
	 * Setter method for percentage
	 * @param percentage Percentage of people who voted for the candidate to be set
	 */
	public void setPercentage(String percentage) {
		this.percentage = Double.parseDouble(percentage); // converts String to double
	}
	
}