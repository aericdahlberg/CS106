/**
 * This class stores one row of the dataset. 
 * 
 * @author: Annie Wernerfelt, Eric Dahlberg
 * @version: May 11th, 2021
 */
package deduplication.sqf;

public class VoterData {

	/**
	 * the String lastName is the last name of the voter
	 *  the String firstName is the first name of the voter
	 */
	private String lastName;
	private String firstName;
	
	/**
	 * constructor for the VoterData class
	 * @param args takes in an array of strings from the CSV
	 */
	public VoterData(String[] args) {
		this.lastName=args[3];
		this.firstName=args[4];		
	}
	
	/**
	 * getters and setters for first and last name variables
	 * getFullName() combines a voter's first and last name, and is used for the hash deduplication method
	 */
	public String getFullName() {
		return lastName + " " + firstName;
	}
	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	
	/**
	 * toString method for the VoterData class
	 * calling toString on an instance of VoterData will return the voter's last name and first name as a string
	 */
	public String toString() {
		return lastName + " " + firstName;
	}
	
	/**
	 * compareTo method for the VoterData class
	 * This method first compares voters based on their last name, and if their last name is the same it 
	 * compares their first name. 
	 * @param voter is the VoterData object being compared
	 * @return -1 if "this" comes later lexicographically, 1 if "this" comes before lexicographically, and 0 if 
	 * the two are lexicographically the same 
	 */
	public int compareTo(VoterData voter) {
		if (this.lastName.compareTo(voter.lastName) < 0)
			{return -1;}
		if (this.lastName.compareTo(voter.lastName) > 0)
			{return 1;}
		else {
			if (this.firstName.compareTo(voter.firstName) < 0)
				{return -1;}
			if (this.firstName.compareTo(voter.firstName) > 0)
				{return 1;}
			else {return 0;}
			
		}	
	}
}
