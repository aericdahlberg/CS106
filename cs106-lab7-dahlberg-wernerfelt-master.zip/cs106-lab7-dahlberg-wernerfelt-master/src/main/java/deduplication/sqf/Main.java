/**
 * The main driver program for lab 7. 
 * 
 * This program calculates the runtime of the fibonacci algorithm and our deduplication methods. It also creates plots of the runtime
 * data. We also used it to test the deduplication methods that we wrote. 
 * 
 * @author: Annie Wernerfelt, Eric Dahlberg
 * @version: May 11th, 2021
 */
package deduplication.sqf;

import java.util.ArrayList;

import tech.tablesaw.api.DoubleColumn;
import tech.tablesaw.api.StringColumn;
import tech.tablesaw.api.Table;
import tech.tablesaw.plotly.Plot;
import tech.tablesaw.plotly.api.LinePlot;

/**
 * TODO
 */
public class Main {

    public static void main(String[] args) {
    	/**
    	 * this instance of VoterDataSet takes in the command line as an input. It includes "vote_files" in the 
    	 * string so that the computer can locate the file in the correct folder. 
    	 */
    	VoterDataset votes = new VoterDataset("vote_files/"+args[0]);
     	
    	/**
    	 * output for part 4
    	 */
    	System.out.println("Records given:" + votes.getVoterRow().size());
    	System.out.println("Attributes checked:LAST_NAME,FIRST_NAME");
    	System.out.println("Duplicates found:" + (votes.getVoterRow().size()-votes.hashLinearDeduplication().size()));
    	
    	/**
    	 * this code was used for part 3, runtime analysis of the deduplication methods
    	 */
//    	System.out.println(Util.calcTimeAllPairs());
//    	System.out.println(Util.calcTimeHash());
//    	System.out.println(Util.calcTimeQS()); 

    	/**
    	 * this code makes a graph of fibonacci runtime for part 1
    	 */
//    	for(int i=20;i<45;i+=3) {
//    		System.out.println(i + ": " + Util.calcFibTime(i));
//    	}
//    	
//       double[] xvals = {20, 23, 26, 29, 32, 35, 38};
//   	 double[] yvals = {1, 1, 0, 3, 15, 53, 216};
//
//   	 DoubleColumn column1 = DoubleColumn.create("fibonacci number", xvals);
//   	 DoubleColumn column2 = DoubleColumn.create("runtime (milliseconds)", yvals);
//
//   	 Table table = Table.create("for plot");
//   	 table.addColumns(column1, column2);
//   	 Plot.show(LinePlot.create("fib runtime", table, "fibonacci number", "runtime (milliseconds)"));
   	 
    	/**
    	 * this code makes a graph of runtime for part 3
    	 */
//    	double[] xvals = {10000, 5000, 1000, 500, 100, 10000, 5000, 1000, 500, 100, 10000, 5000, 1000, 500, 100};
//    	double[] yvals = {8, 6, 3, 2, 2, 935, 219, 25, 9, 1, 21, 10, 3, 2, 0};
//    	String[] categories = {"Hash", "Hash", "Hash", "Hash", "Hash", "AllPairs", "AllPairs", "AllPairs", "AllPairs", "AllPairs", "QuickSort", "QuickSort", "QuickSort", "QuickSort", "QuickSort"};
//    	
//    	DoubleColumn column1 = DoubleColumn.create("numRows", xvals);
//    	DoubleColumn column2 = DoubleColumn.create("time(ms)", yvals);
//
//    	StringColumn catcolumn = StringColumn.create("algorithm", categories);
//    	Table table = Table.create("for plot");
//    	table.addColumns(column1, column2, catcolumn);
//    	Plot.show(LinePlot.create("Runtime", table, "numRows", "time(ms)", "algorithm"));
    	
    	/**
    	 * this code was used to test the deduplication methods
    	 */
//    	System.out.println("Size in main(AllPairs): " + votes.allPairsDeduplication().size());
//    	System.out.println("Size in main(Hash): " + votes.hashLinearDeduplication().size());
    	
//    	System.out.println("QuickSort Output: " + votes.quickSort(votes.getVoterRow(), 0, votes.getVoterRow().size()-1).toString());

//    	System.out.println("Size in main(QuickSort): " + votes.quicksortDeduplication().size());
    }
}
