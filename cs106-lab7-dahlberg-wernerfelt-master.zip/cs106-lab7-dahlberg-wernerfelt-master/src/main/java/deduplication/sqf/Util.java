/**
 * This class stores is used to calculate the runtime of fibonacci as well as the deduplication methods
 * 
 * @author: Annie Wernerfelt, Eric Dahlberg
 * @version: May 11th, 2021
 */
package deduplication.sqf;

public class Util {
	/**
	 * this instance of VoterDataset was used to calculate runtime for each deduplication method
	 */
	static VoterDataset votes = new VoterDataset("vote_files/SWVF_1_22_short.txt");

	/**
	 * this main method was created in part 1, and we pasted in the example code. 
	 */
	 public static void main() {
		int n = 0;
		double start = startTimer();
		double result = fib(n);
		double end = endTimer();
		double timeSec = secondsElapsed(start, end);
	 }
	 
	 /**
	  * This method starts a timer for running methods
	  * @return the current time, in ms
	  */
	 public static double startTimer() {
		 return System.currentTimeMillis();
	 }
	 
	 /**
	  * This method stops a timer for running methods
	  * @return the current time, in ms
	  */
	 public static double endTimer() {
		 return System.currentTimeMillis();
	 }
	 
	 /**
	  * this method calculates the time between the start and end of a method being run
	  * @param start is the start time
	  * @param end is the stopping time
	  * @return the elapsed time, in ms
	  */
	 public static double secondsElapsed(double start, double end) {
		 return end-start;
	 }
	 
	 /**
	  * this is a simple fibonacci method
	  * @param integer is the index of fibonacci number being calculated
	  * @return the fibonacci nuber
	  */
	 public static int fib(int integer) {
		 if(integer == 0) {
				return 1;
			}
		if(integer == 1) {
			return 0;
		}
		else {
			return fib(integer-1)+fib(integer-2);
		}
	 }
	 
	 /**
	  * This method calculates time taken by the fibonacci methods for a given index n
	  * @param n is the fib index 
	  * @return the time taken to find the fibonacci number
	  */
	 public static double calcFibTime(int n) {
		 double s = startTimer();
		 fib(n);
		 double e = endTimer();
		 return secondsElapsed(s, e);
	 }
	  
	 /**
	  * This method calculates time taken by the allPairs deduplication method
	  * @return the runtime
	  */
	 public static double calcTimeAllPairs() {
		 double s = startTimer();
		 votes.allPairsDeduplication().size();
		 double e = endTimer();
		 return secondsElapsed(s, e);
	 }
	 
	 /**
	  * This method calculates time taken by the Hash deduplication method
	  * @return the runtime
	  */
	 public static double calcTimeHash() {
		 double s = startTimer();
		 votes.hashLinearDeduplication().size();
		 double e = endTimer();
		 return secondsElapsed(s, e);
	 }
	  
	 /**
	  * This method calculates time taken by the QuickSort deduplication method
	  * @return the runtime
	  */
	 public static double calcTimeQS() {
		 double s = startTimer();
		 votes.quicksortDeduplication().size();
		 double e = endTimer();
		 return secondsElapsed(s, e);
	 }
}
