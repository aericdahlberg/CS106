/**
 * This class stores the full dataset of voters. An ArrayList called voterRow contains objects of type VoterData, each of 
 * which represents one row of the CSV file. The class also contains deduplication methods. 
 * 
 * @author: Annie Wernerfelt, Eric Dahlberg
 * @version: May 11th, 2021
 */

package deduplication.sqf;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

import com.opencsv.CSVReaderHeaderAware;

public class VoterDataset {
	/**
	 * initialize variables
	 * voterRow is an ArrayList that stores each row from the CSV as an object of type VoterData
	 * allPairsList was used to build an ArrayList in our allPairsDeduplication method
	 */
	ArrayList <VoterData> voterRow = new ArrayList <VoterData>();
	ArrayList <VoterData> allPairsList = new ArrayList<VoterData>();
	
	/**
	 * constructor for the VoterDataset class
	 * @param fileName takes in the name of the CSV file so that the data can be read in
	 */
	public VoterDataset (String fileName) {
    //taking pool data information and reading it into the for loop
    	/**
    	 * this code reads in data from the CSV file and makes each row an instance of VoterData. It then
    	 * adds each instance to the ArrayList called voterRow. 
    	 */
 		try {
 			// Reads in the data from the csv file and stores them in an ArrayList in which
    		// each row of data is an array of Strings
    		CSVReaderHeaderAware reader = new CSVReaderHeaderAware(new FileReader(fileName));
    		ArrayList<String[]> voterString = new ArrayList<String[]>(reader.readAll());
 			reader.close();
 			
 			// Goes over each String array in the ArrayList 
 			// to create VoterData objects based on the information on the rows
 			for (int j = 0; j < voterString.size(); j++) {
 				VoterData voterObj = new VoterData(voterString.get(j));
 				voterRow.add(voterObj);// inserts each candidate to the ArrayList
 			}
 			//System.out.println(voterRow);
    	} catch (FileNotFoundException e) {
    		// handles FileNotFoundException
    		System.out.println("File not found!");
    	} catch (IOException e) {
    		// handles IOException
    		System.out.println("IOException!");
    	}
 	}
	
	/**
	 * getter for voterRow, which is the ArrayList storing our data. This was used mostly for testing
	 * @return voterRow
	 */
	public ArrayList<VoterData> getVoterRow() {
		return voterRow;
	}

	/**
	 * All Pairs method for deduplication: For each element in the ArrayList, this method iterates over every other element 
	 * in the ArrayList and only adds the current element if there are no duplicates of it. Because we can't use remove(),
	 * we created a new ArrayList called allPairsList, iterate over voterRow and add all non dublicates to the new ArrayList. 
	 * As the list iterates eventually two elements that were the same will not in the shortened array list, so the element 
	 * will be added to the new ArrayList. 
	 * O(n^2)
	 * @return the newly constructed ArrayList with no duplicates
	 */
	public ArrayList<VoterData> allPairsDeduplication() {
		ArrayList<VoterData> allPairsList = new ArrayList<VoterData>();
		for(int i=0;i<voterRow.size();i++) {
			Boolean duplicate = false;
			for(int x=i+1;x<voterRow.size();x++) {
				if(voterRow.get(i).compareTo(voterRow.get(x)) == 0) { // if i has a duplicate
					duplicate = true;
				}
			}
			if(duplicate==false) {
				allPairsList.add(voterRow.get(i)); 
			}
		}
		return allPairsList;
	}
    
	/**
	 * Hash method for deduplication: this method checks if the key of each instance of voterRow already exists
	 * in a hashmap. The key is the person's first and last name, as a string. If the key isn't aleady there, it adds
	 * the element to the arrayList called finalArrayList.
	 * @return the arrayList of elements with no duplicates 
	 * O(n)
	 */
	public  ArrayList<VoterData> hashLinearDeduplication() {
		ArrayList<VoterData> finalArrayList = new ArrayList<VoterData>(); 
		ProbeHashMap<String, VoterData> voterHashMap = new ProbeHashMap<String, VoterData>(1000003);
		for(int i=0;i<voterRow.size();i++) {
			if(voterHashMap.get(voterRow.get(i).getFullName()) == null) {
				finalArrayList.add(voterRow.get(i));
			}
			voterHashMap.put(voterRow.get(i).getFullName(),voterRow.get(i));
		}	
		return finalArrayList;
	}
	
	/**
	 * Quick Sort method for deduplication: this method calls quickSort on the voterRow ArrayList. Then it checks 
	 * if the element in front of an element (i) are equal using compareTo. If the element in front (i+1) is different
	 * from the given element, add i to the list called quickSortList. We can do this because all elements that are the 
	 * same will be next to each other in the quickSortList because we call quickSort on the list at the start.
	 * @return quickSortList, the newly built list
	 * O(n)
	 */
	public ArrayList<VoterData> quicksortDeduplication() {
		quickSort(voterRow,0,voterRow.size()-1);
		ArrayList<VoterData> quickSortList = new ArrayList<VoterData>();
	
		for(int i=0;i<voterRow.size()-1;i++) {
			Boolean duplicate = false;
			if (voterRow.get(i).compareTo(voterRow.get(i+1))==0) {
				duplicate = true;
			}
			if(duplicate==false) {
				quickSortList.add(voterRow.get(i)); 
			}
		}
		quickSortList.add(voterRow.get(voterRow.size()-1));
		return quickSortList;
	}
	/**
	 * quickSort method: this method is called in quicksortDeduplication. Using a pivot and other Index,
	 * this method sorts the data alphabetically
	 * moving otherIndex closer to the pivot by one iteration each time, when pivot and otherIndex
	 * are at the same index, it recursivly calls itself with two smaller indexes.
	 * O(log n)
	 * @param alist is any ArrayList of type voterData. 
	 * @param firstIndex is assigned as the pivot
	 * @param lastIndex is assigned as the other index, and is compared to the pivot
	 * @return the sorted ArrayList
	 */
	public ArrayList<VoterData> quickSort(ArrayList<VoterData> alist, int firstIndex, int lastIndex) {
		int pivot = firstIndex;
		int otherIndex = lastIndex;
		while (pivot != otherIndex) {
			if(pivot < otherIndex) { // pivot is to the left of otherIndex
				if(alist.get(pivot).compareTo(alist.get(otherIndex)) <= 0) {
					otherIndex--;
				} 
				else if(alist.get(pivot).compareTo(alist.get(otherIndex)) > 0) {
					swap(pivot, otherIndex);
					int tempPivot = pivot;
					pivot = otherIndex; // we also have to swap the indices that pivot and otherIndex point to after swapping
					otherIndex = tempPivot;
					otherIndex++;
				}
			}
			else if(pivot > otherIndex) { // pivot is to the right of otherIndex
				if(alist.get(pivot).compareTo(alist.get(otherIndex)) >= 0) {
					otherIndex++;
				}
				else if(alist.get(pivot).compareTo(alist.get(otherIndex)) < 0) {
					swap(pivot, otherIndex);
					int tempPivot = pivot;
					pivot = otherIndex;
					otherIndex = tempPivot;
					otherIndex--;
				}
			}
			if (pivot==otherIndex) { //if pivot and otherIndex become the same, recursively call the method on either side of the pivot
				if(pivot!=firstIndex) {
					quickSort(alist, firstIndex, pivot-1);
				}
				if(pivot!=lastIndex) {
					quickSort(alist, pivot+1, lastIndex);	
				}
			}
		}
		return alist;
	}
	
	/**
	 * The swap method is used in quickSort. It swaps the elements of two indices
	 * @param first index
	 * @param second index
	 */
	public void swap (int first, int second) {
		VoterData firstE = voterRow.get(first);
		voterRow.set(first,  voterRow.get(second));
		voterRow.set(second, firstE);
	}
}
