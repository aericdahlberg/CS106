## CS 106 Lab 7 - Deduplication (A pair programming lab)
## Choosing the partner
You are free to choose your partner for this lab i.e. you can choose to work with a student who you have already worked with or someone else. 

Member1: Annie Wernerfelt

Member2: Eric Dahlberg 

Number of Late Days Using for this lab:

---
## Tasks: 
[Tasks are listed here](https://github.com/Haverford-College-USA/cs106-lab7/blob/master/Tasks.md)

## Files
The lab files are available [here as well](https://drive.google.com/drive/folders/1m3ZQEFMVSLzL-BC3qnRieLtZEk3r_u3e?usp=sharing) 

### Runtime Analysis

When running vote_files/SWVF_1_22_med.txt (one of the medium data files), allPairsDeduplication takes 346560 milliseconds, hashLinearDeduplication takes 264 milliseconds, and quickSortDeduplication takes 266 milliseconds. 
The runtime of allPairsDeduplication is the slowest. This is because it uses O(n^2) runtime. It has a set of nested for loops which each iterate through every row. 

The runtime of hashLinearDeduplication is O(n). This is because it only has one for loop that iterates through the whole list, so O(n) will be the worst case. The runtime of ArrayList.get(i) is O(1) because the data structure is an ArrayList. So the ArrayList.get(i) statements don't affect the overall runtime. 

The runtime of quicksortDeduplication is O(n log n). The runtime of quickSort is log n; the time of the partition method is O(n) because that's how long it takes to find the pivot. Then each recursive call divides that operation by 2 because the pivot is on average in the middle. So for each row the partition time becomes ((n/2)/2)/2... etc. Once the pivot equals the other index there will have been log n rows in the worst case. So quickSort takes O(log n) time, and quicksortDeduplication calls quickSort so it will also take log n time, plus O(n) because it has a for loop after it calls the method. 


---

### Lab Questionnaire

(None of your answers below will affect your grade; this is to help refine lab
assignments in the future)

1. Approximately, how many hours did you take to complete this lab? (provide
  your answer as a single integer on the line below)
  9

2. How difficult did you find this lab? (1-5, with 5 being very difficult and 1
  being very easy)
  4

3. Describe the biggest challenge you faced on this lab:
Implementing quickSort
