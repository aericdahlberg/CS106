package polling.treesheaps;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
/* The main driver program for Lab 6
 * 
 * The goal of this lab is to practice with ArrayHeaps to 
 * work on polling data from the 2020 U.S. presidential election.
 * 
 * @author: Eric Dahlberg
 * @version: April 28, 2021
 */
import java.util.ArrayList;
import java.util.Arrays;

import com.opencsv.CSVReaderHeaderAware;

public class Main {

    public static void main(String[] args) {

    //	Testing toString method and insert methods for Integers
    //  They seem to work!
//    	
  	ArrayHeap<Integer> intHeap = new ArrayHeap<Integer>();
    	
    	intHeap.insert(4); 
    	intHeap.insert(3);
    	intHeap.insert(-1);
    	intHeap.insert(0);
    	intHeap.insert(543);
    	intHeap.insert(20555);
    	intHeap.insert(-70);
    	intHeap.insert(600);
    	intHeap.insert(40);
    	intHeap.insert(-20);
    	intHeap.insert(3);
    	intHeap.insert(-1);
    	intHeap.insert(-2);
    	intHeap.insert(0);
    	intHeap.insert(6);
    	intHeap.insert(-7);
    	intHeap.insert(6);
    	intHeap.insert(-4);
    	intHeap.insert(20);
    	
    	System.out.print(intHeap.removeMax());
    	System.out.print(intHeap.toString());
//    	System.out.print(intHeap.removeMax());
//    	System.out.print(intHeap.removeMax());
//    	System.out.print(intHeap.removeMax());
//    	System.out.print(intHeap.toString());
//    	
    	//Testing toString method and insert methods for Integers
//    	ArrayHeap<Character> letterHeap = new ArrayHeap<Character>();
//        letterHeap.insert('A');
//        letterHeap.insert('C');
//      
//       
//        letterHeap.insert('G');
//        letterHeap.insert('B');
//        letterHeap.insert('D');
//        letterHeap.insert('W');
//        letterHeap.insert('X');
//        letterHeap.insert('Y');
//        letterHeap.insert('S');
//        letterHeap.insert('F');
//        letterHeap.insert('T');
//        letterHeap.insert('F');
//        letterHeap.insert('F');
//        System.out.print(letterHeap.toString());
//    	
//    	heap.sort();
//        System.out.println(array);
//    	
   
    	Integer[] arr = {-2,3,9,-7,1,2,6,-3};
        ArrayList<Integer> array = new ArrayList<Integer>(Arrays.asList(arr));
    	System.out.print(array.toString());
    	
    	ArrayHeap<Integer> heap = new ArrayHeap<Integer>(array);
        System.out.println(heap);
        heap.sort();
        
        
        
        
        
        //part 3
        //initializing pollData as an Arraylist
        
        ArrayList<Candidates> pollData = new ArrayList<Candidates>();
//        
//        //poll_data/dempres_20190718_3.csv to put into reader
//        //taking pool data information and reading it into the for loop
//        for (int i = 0; i < args.length; i++) {
//        	
//    		try {
//    			// Reads in the data from the csv file and stores them in an ArrayList in which
//        		// each row of data is an array of Strings
//        		CSVReaderHeaderAware reader = new CSVReaderHeaderAware(new FileReader(args[i]));
//        		ArrayList<String[]> myEntries = new ArrayList<String[]>(reader.readAll());
//    			reader.close();
//    			
//    			// Goes over each String array in the ArrayList 
//    			// to create Candidate objects based on the information on the rows
//    			for (int j = 0; j < myEntries.size(); j++) {
//    				Candidates candidates = new Candidates(myEntries.get(j));
//    				pollData.add(candidates); // inserts each candidate to the ArrayList
//    			}
// 
//        	} catch (FileNotFoundException e) {
//        		// handles FileNotFoundException
//        		System.out.println("File not found!");
//        	} catch (IOException e) {
//        		// handles IOException
//        		System.out.println("IOException!");
//        	}
//    	}
        
        
        //creating a candidate Heap of type ArrayHeap
        ArrayHeap<Candidates> candidateHeap = new ArrayHeap<Candidates>(pollData);
        //prints candidates in order vvv by removingMax and printing the return value
        System.out.print(candidateHeap);
        while (candidateHeap.size() !=0){
        	System.out.println(candidateHeap.removeMax());
//        	
        }
        	
    }
}
