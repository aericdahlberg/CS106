package polling.treesheaps;
/*
 * The ArrayHeap class for lab 6
 * 
 * This class has all the methods for sorting and organizing ArrayHeaps
 *  
 * @author: Eric Dahlberg
 * @version: April 27, 2021
 */

import java.util.ArrayList;

public class ArrayHeap<E extends Comparable<E>> implements PriorityQueue<E> {
	
	private ArrayList<E> aHeap = new ArrayList<E>();

	
	/*
	 * this insert method adds an element to an arraylist
	 */
	@Override
	public void insert(E element) {
		//takes in anything, E
		aHeap.add(element);	
		// uses an arrayList built in function to add an 
		//element to the end of the list
		bubbleUp(size()-1);
		/// calls bubble up function on the last element to organize the Arraylist	
	}
	
	/*
	 * constructors:
	 * 1.First constructor just turns something into type ArrayHeap,
	 * but this is just what we call an organized array
	 */
	public ArrayHeap() {
//		ArrayHeap <E> aHeap = new ArrayHeap();			
	}

	//2. Second constructor has an ArrayList inputed and organizes is
	// by calling bubble up on all indexes starting at the begining
	//and going through all of them
	public ArrayHeap(ArrayList<E> input) {
		 this.aHeap = input;	
		 for (int i =1; i<size(); i++) {
			 bubbleUp(i); 
		 
		 }
	}
	// max method returns max, or null if aHeap is empty
	@Override
	public E max() {
		if (aHeap.size() == 0) {return null;}
		else {return aHeap.get(0);} 
	}
	
	/*
	 * removeMax method:
	 * 1.sets max = to the first element in array
	 * 2.swaps the last element in array with the first
	 * 3.removes last array
	 * 4. calls bubbleDown on the first element to sort the array
	 * 5.returns variable max
	 */
	@Override
	public E removeMax() {
		// TODO Auto-generated method stub
		E max = aHeap.get(0); 
		swap(0, size()-1);
		aHeap.remove(size()-1);
		bubbleDown(0);
//		System.out.println(aHeap);
		return max ;
	}

	@Override
	//uses build in .size()method for calculation
	public int size() {
		// TODO Auto-generated method stub
		return aHeap.size();
	}

	@Override
	/*
	 * sees if size = zero or not, then returns a bool
	 */
	public boolean isEmpty() {
		// TODO Auto-generated method stub
		return (size()==0);
		
	}
	//Calculates parent of a child
	public int parent(int childIndex) {
		return  (childIndex -1)/2;
	}
	
	//Calculates left child of a parent
	public int leftChild(int parentIndex) {
		return  (parentIndex*2+1);
	}
	
	//Calculates right child of a parent
	public int rightChild(int parentIndex) {
		return  (parentIndex*2+2);
	}
	
	
	/*
	 * swapping child and parent, and setting their values = to the other
	 * in the other's array spot
	 * (uses built in set method for arraylist)
	 */
	public void swap (int child, int parent) {
		E kid = aHeap.get(child);
		E rents = aHeap.get(parent);
		aHeap.set(parent, kid);
		aHeap.set(child, rents);
	}
	
	/*
	 * uses compile to compile string together, creates a 
	 * new line every power of 2 to create a new line 
	 * gets aHeap(i), adds it to compile
	 * returns compile 
	 */
	@Override
	public String toString() {
		int k= 0;
		String compile = "";
		for (int i=0; i<aHeap.size(); i++) {
			if (Math.pow(2,k)-1 == i) {
				compile += "\n";
				k++;		
			}
			compile+= " " + aHeap.get(i);
		}
		return compile;
	}
	
	/*
	 * sorts an arraylist
	 * starts at the end of the list and swaps that with the beginning of the list
	 * using a for loop.
	 *  in that same for loop calls another loop to bubblesort the elements in aHeap
	 *  starting with 1 and ending at size -z
	 */
	public void sort() {
		for (int c=aHeap.size()-1; c>0; c--){
			swap(0, c); 
			System.out.println(aHeap);
			 for (int z =1; z<size()/z; z++) {
				 bubbleUpSort(z); 
				 
			 }
			
		}
		
	}

	//calls the Index of the array and compares it to its parent index,
	//if it is bigger it swaps their places and redefines index.
	//uses a while loop to continue
	public void bubbleUp(int Index) {
		int up = parent(Index);
		if (Index != 0) {
			while (aHeap.get(Index).compareTo(aHeap.get(up))>0) {
				swap(Index, up);                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                
				Index = parent(Index);
				up = parent(Index);
				
			}
		}
	}
	
	//calls the Index of the array and compares it to its parent index,
	//if it is bigger it swaps their places and redefines index.
	//uses a while loop to continue
	public void bubbleUpSort(int Index) {
		int up = parent(Index);
		if (Index != 0) {
			while (aHeap.get(Index).compareTo(aHeap.get(up))>0) {
				swap(Index, up);     
				Index = parent(Index);
				up = parent(Index);
				
			}
		}
	}
	
	
	/*
	 * bubble down
	 * 
	 * 1. checks to see if empty,
	 * 2. then checks to see if there is a left child
	 * 3. if statement to see if there is a right child and in those if statements
	 * comparing statements to the left and right children and then to parent
	 * function to see if they should swap or not
	 * 4. Then another piece outside of 3., that sees if left child is bigger than 
	 * the parent function and if it is, then swapping them. 
	 * (in all swapping methods, redefining indexes, so that when the while statement
	 * is run again, the index and children have changed, which makes this repetitive)
	 * 5. breaking if index has reached the right pace. 
	 */
	public void bubbleDown(int Index) {
		int Rdown = rightChild(Index);
		int Ldown = leftChild(Index);
		if (aHeap.size() != 0) {
			while (leftChild(Index)< size()-1) {
				if (rightChild(Index) < size()-1 ) {
					if (aHeap.get(Ldown).compareTo(aHeap.get(Rdown))>=0 &&
						aHeap.get(Ldown).compareTo(aHeap.get(Index))>=0) {
						swap (Ldown, Index);
						Index = leftChild(Index);
						Rdown = rightChild(Index);
						Ldown = leftChild(Index);
					}
					else if (aHeap.get(Ldown).compareTo(aHeap.get(Rdown))<0 &&
						aHeap.get(Rdown).compareTo(aHeap.get(Index)) >= 0) {
						swap (Rdown, Index);
						Index = rightChild(Index);
						Rdown = rightChild(Index);
						Ldown = leftChild(Index);
					}
				}
				
					
				else if (aHeap.get(Ldown).compareTo(aHeap.get(Index))>=0) {
					swap (Rdown, Index);
					Index = rightChild(Index);
					Rdown = rightChild(Index);
					Ldown = leftChild(Index);
				}
				else {
					break;
				}
				
			}
		}
	}
	
	
}

